'use strict';
// Mojang's "rules" decide which libraries and arguments apply to this OS/arch/feature set.
const os = require('os');

function osName() {
  if (process.platform === 'win32') return 'windows';
  if (process.platform === 'darwin') return 'osx';
  return 'linux';
}

function archName() {
  return process.arch === 'ia32' ? 'x86' : process.arch;
}

function ruleMatches(rule, features = {}) {
  if (rule.os) {
    if (rule.os.name && rule.os.name !== osName()) return false;
    if (rule.os.arch && rule.os.arch !== archName()) return false;
    if (rule.os.version) {
      try { if (!new RegExp(rule.os.version).test(os.release())) return false; } catch { return false; }
    }
  }
  if (rule.features) {
    for (const [k, v] of Object.entries(rule.features)) {
      if (Boolean(features[k]) !== v) return false;
    }
  }
  return true;
}

// No rules = allowed. Otherwise the last matching rule wins.
function allowed(rules, features) {
  if (!rules || !rules.length) return true;
  let result = false;
  for (const r of rules) {
    if (ruleMatches(r, features)) result = r.action === 'allow';
  }
  return result;
}

module.exports = { allowed, osName, archName };
