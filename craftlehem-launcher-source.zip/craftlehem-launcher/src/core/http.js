'use strict';
// Network helpers: JSON requests with retries, verified file downloads, and a
// small worker pool so thousands of library/asset files download in parallel.
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');

const UA = 'CraftlehemLauncher/0.1 (+https://github.com/coldskiess)';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function request(url, opts = {}, tries = 4) {
  let lastErr;
  for (let i = 0; i < tries; i++) {
    try {
      const res = await fetch(url, {
        ...opts,
        headers: { 'User-Agent': UA, ...(opts.headers || {}) },
        signal: AbortSignal.timeout(opts.timeout || 60000),
      });
      // Retry on rate limits and server errors; everything else is final.
      if (res.status === 429 || res.status >= 500) {
        lastErr = new Error(`HTTP ${res.status} for ${url}`);
        await sleep(500 * 2 ** i);
        continue;
      }
      return res;
    } catch (e) {
      lastErr = e;
      await sleep(500 * 2 ** i);
    }
  }
  throw lastErr;
}

async function getJson(url, opts) {
  const res = await request(url, opts);
  if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
  return res.json();
}

async function postJson(url, body, headers = {}) {
  const res = await request(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json', ...headers },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  let data;
  try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text }; }
  if (!res.ok) {
    const err = new Error(`HTTP ${res.status} for ${url}`);
    err.status = res.status; err.data = data;
    throw err;
  }
  return data;
}

async function postForm(url, form) {
  const res = await request(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(form).toString(),
  });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, ok: res.ok, data };
}

function hashFile(file, algo = 'sha1') {
  return new Promise((resolve, reject) => {
    const h = crypto.createHash(algo);
    fs.createReadStream(file).on('error', reject).on('data', (d) => h.update(d)).on('end', () => resolve(h.digest('hex')));
  });
}

// True if the file exists and matches the expected hash (or size, when no hash is known).
async function isValid(file, sha1, size) {
  try {
    const st = await fsp.stat(file);
    if (size && st.size !== size) return false;
    if (sha1) return (await hashFile(file)) === sha1.toLowerCase();
    return st.size > 0;
  } catch { return false; }
}

async function download(url, dest, { sha1, size } = {}) {
  if (await isValid(dest, sha1, size)) return false;
  await fsp.mkdir(path.dirname(dest), { recursive: true });
  let lastErr;
  for (let i = 0; i < 4; i++) {
    const tmp = `${dest}.${process.pid}.${Math.random().toString(36).slice(2)}.part`;
    try {
      const res = await request(url, { timeout: 300000 });
      if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
      const buf = Buffer.from(await res.arrayBuffer());
      if (sha1) {
        const got = crypto.createHash('sha1').update(buf).digest('hex');
        if (got !== sha1.toLowerCase()) throw new Error(`Checksum mismatch for ${url}`);
      }
      await fsp.writeFile(tmp, buf);
      await fsp.rename(tmp, dest);
      return true;
    } catch (e) {
      lastErr = e;
      await fsp.rm(tmp, { force: true });
      if (/HTTP 404/.test(e.message)) break;
      await sleep(500 * 2 ** i);
    }
  }
  throw lastErr;
}

// Run download jobs with limited parallelism, reporting progress as files finish.
async function downloadAll(jobs, { concurrency = 16, onProgress, label = 'Downloading' } = {}) {
  let done = 0;
  const total = jobs.length;
  const queue = jobs.slice();
  const errors = [];
  onProgress && onProgress({ label, done, total });
  async function worker() {
    while (queue.length) {
      const job = queue.shift();
      try { await download(job.url, job.dest, job); }
      catch (e) { errors.push(`${job.url}: ${e.message}`); }
      done++;
      onProgress && onProgress({ label, done, total });
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, total || 1) }, worker));
  if (errors.length) {
    const e = new Error(`${errors.length} file(s) failed to download:\n${errors.slice(0, 5).join('\n')}`);
    e.failures = errors;
    throw e;
  }
}

module.exports = { request, getJson, postJson, postForm, download, downloadAll, hashFile, isValid, UA, sleep };
