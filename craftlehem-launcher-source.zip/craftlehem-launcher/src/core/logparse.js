'use strict';
// Minecraft's launcher logging config prints log4j XML events. This turns that
// stream back into readable lines: { time, level, thread, logger, text }.
class LogParser {
  constructor() { this.buf = ''; }

  push(chunk) {
    this.buf += chunk;
    const out = [];
    for (;;) {
      const start = this.buf.indexOf('<log4j:Event');
      if (start === -1) {
        // Plain text (older versions, our own messages). Keep any partial last line.
        const nl = this.buf.lastIndexOf('\n');
        if (nl === -1) break;
        for (const line of this.buf.slice(0, nl).split('\n')) if (line.trim()) out.push(plain(line));
        this.buf = this.buf.slice(nl + 1);
        break;
      }
      if (start > 0) {
        for (const line of this.buf.slice(0, start).split('\n')) if (line.trim()) out.push(plain(line));
        this.buf = this.buf.slice(start);
        continue;
      }
      const end = this.buf.indexOf('</log4j:Event>');
      if (end === -1) break;
      out.push(parseEvent(this.buf.slice(0, end)));
      this.buf = this.buf.slice(end + '</log4j:Event>'.length);
    }
    return out;
  }
}

function attr(xml, name) {
  const m = new RegExp(`${name}="([^"]*)"`).exec(xml);
  return m ? m[1] : '';
}

function cdata(xml, tag) {
  const m = new RegExp(`<log4j:${tag}><!\\[CDATA\\[([\\s\\S]*?)\\]\\]></log4j:${tag}>`).exec(xml);
  return m ? m[1] : '';
}

function parseEvent(xml) {
  const ts = Number(attr(xml, 'timestamp'));
  const msg = cdata(xml, 'Message');
  const thr = cdata(xml, 'Throwable');
  return {
    time: ts ? new Date(ts).toTimeString().slice(0, 8) : '',
    level: attr(xml, 'level') || 'INFO',
    thread: attr(xml, 'thread'),
    logger: attr(xml, 'logger'),
    text: thr ? `${msg}\n${thr}` : msg,
  };
}

function plain(line) {
  const m = /^\[(\d\d:\d\d:\d\d)\] \[([^\]/]+)\/(\w+)\]:? ?(.*)$/.exec(line);
  if (m) return { time: m[1], thread: m[2], level: m[3], logger: '', text: m[4] };
  const level = /\bERROR\b|Exception/.test(line) ? 'ERROR' : /\bWARN\b/.test(line) ? 'WARN' : line.startsWith('[Craftlehem]') ? 'LAUNCHER' : 'INFO';
  return { time: '', level, thread: '', logger: '', text: line };
}

module.exports = { LogParser };
