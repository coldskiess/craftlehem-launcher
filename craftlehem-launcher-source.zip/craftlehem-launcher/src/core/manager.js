'use strict';
// The launcher's "brain": instances, settings, accounts and running games. The
// Electron main process owns one Manager and the window talks to it over IPC.
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const { EventEmitter } = require('events');
const { Paths } = require('./paths');
const L = require('./launch');
const Loaders = require('./loaders');
const Modrinth = require('./modrinth');
const MS = require('./auth/microsoft');
const V = require('./versions');
const { ping } = require('./serverping');
const { LogParser } = require('./logparse');
const BUILD = require('./build-config.json');

const DEFAULT_SETTINGS = {
  clientId: '',
  memoryMin: 2048,
  memoryMax: 8192,
  preset: 'optimized',
  javaPath: '',
  extraJvmArgs: '',
  closeOnLaunch: false,
  featuredServer: { name: 'Craftlehem', host: 'join.seshlehem.net', port: 25565 },
};

function slugify(name) {
  return (name || 'instance').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'instance';
}

async function readJson(file, fallback) {
  try { return JSON.parse(await fsp.readFile(file, 'utf8')); } catch { return fallback; }
}

async function writeJson(file, data) {
  await fsp.mkdir(path.dirname(file), { recursive: true });
  const tmp = `${file}.tmp`;
  await fsp.writeFile(tmp, JSON.stringify(data, null, 2));
  await fsp.rename(tmp, file);
}

class Manager extends EventEmitter {
  // crypto: { encrypt(str) -> str, decrypt(str) -> str } (Electron safeStorage in the app)
  constructor(root, crypto) {
    super();
    this.paths = new Paths(root);
    this.crypto = crypto || { encrypt: (s) => s, decrypt: (s) => s };
    this.running = new Map(); // instanceId -> child process
    this.logs = new Map(); // instanceId -> recent parsed log lines
    this.parsers = new Map();
    this.busy = new Set();
    this.loginCancelled = false;
  }

  // ---------- settings ----------
  get settingsFile() { return path.join(this.paths.root, 'settings.json'); }
  async getSettings() {
    const s = { ...DEFAULT_SETTINGS, ...(await readJson(this.settingsFile, {})) };
    // The release build ships its own approved app ID; a saved value overrides it (for forks/dev).
    s.builtInClientId = Boolean(BUILD.msClientId);
    if (!s.clientId) s.clientId = BUILD.msClientId || '';
    return s;
  }
  async saveSettings(patch) {
    const s = { ...DEFAULT_SETTINGS, ...(await readJson(this.settingsFile, {})), ...patch };
    if (s.clientId === BUILD.msClientId) s.clientId = '';
    delete s.builtInClientId;
    await writeJson(this.settingsFile, s);
    return this.getSettings();
  }

  // ---------- accounts ----------
  get accountsFile() { return path.join(this.paths.root, 'accounts.json'); }
  async readAccounts() { return readJson(this.accountsFile, { selected: null, list: [] }); }
  async listAccounts() {
    const a = await this.readAccounts();
    // Never hand tokens to the window.
    return { selected: a.selected, list: a.list.map(({ uuid, name, type, skin }) => ({ uuid, name, type, skin })) };
  }
  async selectAccount(uuid) {
    const a = await this.readAccounts();
    a.selected = uuid;
    await writeJson(this.accountsFile, a);
  }
  async removeAccount(uuid) {
    const a = await this.readAccounts();
    a.list = a.list.filter((x) => x.uuid !== uuid);
    if (a.selected === uuid) a.selected = a.list[0] ? a.list[0].uuid : null;
    await writeJson(this.accountsFile, a);
  }
  async loginMicrosoft() {
    const { clientId } = await this.getSettings();
    this.loginCancelled = false;
    const { account, refreshToken } = await MS.login(clientId, {
      onCode: (dc) => this.emit('login-code', { userCode: dc.userCode, url: dc.verificationUri }),
      isCancelled: () => this.loginCancelled,
    });
    const a = await this.readAccounts();
    a.list = a.list.filter((x) => x.uuid !== account.uuid);
    a.list.push({ ...account, accessToken: undefined, refresh: this.crypto.encrypt(refreshToken) });
    a.selected = account.uuid;
    await writeJson(this.accountsFile, a);
    return { uuid: account.uuid, name: account.name, type: 'msa', skin: account.skin };
  }
  cancelLogin() { this.loginCancelled = true; }

  // Offline accounts are only offered once a real Microsoft account has been added,
  // the same rule other launchers follow, so they cannot be used to skip buying the game.
  async addOfflineAccount(name) {
    const a = await this.readAccounts();
    if (!a.list.some((x) => x.type === 'msa')) throw new Error('Add a Microsoft account that owns Minecraft first.');
    if (!/^[A-Za-z0-9_]{3,16}$/.test(name)) throw new Error('Names must be 3-16 letters, numbers or underscores.');
    const acc = { type: 'offline', name, uuid: L.offlineUuid(name) };
    a.list = a.list.filter((x) => x.uuid !== acc.uuid);
    a.list.push(acc);
    a.selected = acc.uuid;
    await writeJson(this.accountsFile, a);
    return acc;
  }

  // Get a fresh session for the selected account right before launching.
  async sessionForLaunch() {
    const a = await this.readAccounts();
    const acc = a.list.find((x) => x.uuid === a.selected) || a.list[0];
    if (!acc) throw new Error('Add an account first (Accounts page).');
    if (acc.type !== 'msa') return { type: 'offline', name: acc.name, uuid: L.offlineUuid(acc.name) };
    const { clientId } = await this.getSettings();
    const { account, refreshToken } = await MS.refresh(clientId, this.crypto.decrypt(acc.refresh));
    Object.assign(acc, { name: account.name, skin: account.skin, refresh: this.crypto.encrypt(refreshToken) });
    await writeJson(this.accountsFile, a);
    return { ...account, clientId };
  }

  // ---------- instances ----------
  instanceFile(id) { return path.join(this.paths.instanceDir(id), 'instance.json'); }

  async listInstances() {
    const out = [];
    for (const id of await fsp.readdir(this.paths.instances).catch(() => [])) {
      const inst = await readJson(this.instanceFile(id), null);
      if (inst) out.push({ ...inst, running: this.running.has(id), busy: this.busy.has(id) });
    }
    return out.sort((a, b) => (b.lastPlayed || b.created || 0) - (a.lastPlayed || a.created || 0));
  }

  async getInstance(id) {
    const inst = await readJson(this.instanceFile(id), null);
    if (!inst) throw new Error('That instance no longer exists.');
    return inst;
  }

  async saveInstance(inst) {
    await writeJson(this.instanceFile(inst.id), inst);
    this.emit('instances-changed');
    return inst;
  }

  async newInstanceId(name) {
    const base = slugify(name);
    let id = base, n = 2;
    while (fs.existsSync(this.paths.instanceDir(id))) id = `${base}-${n++}`;
    return id;
  }

  async createInstance({ name, mc, loader = { type: 'vanilla', version: null }, source = null }) {
    if (!mc) throw new Error('Pick a Minecraft version.');
    const id = await this.newInstanceId(name || `${loader.type} ${mc}`);
    const inst = {
      id, name: name || `${mc} ${loader.type === 'vanilla' ? '' : loader.type}`.trim(), mc, loader, source,
      versionId: null, created: Date.now(), lastPlayed: null, playTime: 0,
      memory: null, preset: null, javaPath: null, extraJvmArgs: '',
    };
    await fsp.mkdir(this.paths.gameDir(id), { recursive: true });
    return this.saveInstance(inst);
  }

  async updateInstance(id, patch) {
    const inst = await this.getInstance(id);
    const allowed = ['name', 'memory', 'preset', 'javaPath', 'extraJvmArgs', 'icon', 'server'];
    for (const k of allowed) if (k in patch) inst[k] = patch[k];
    return this.saveInstance(inst);
  }

  async deleteInstance(id) {
    if (this.running.has(id)) throw new Error('Close the game before deleting this instance.');
    await fsp.rm(this.paths.instanceDir(id), { recursive: true, force: true });
    this.emit('instances-changed');
  }

  async listMods(id) {
    const dir = path.join(this.paths.gameDir(id), 'mods');
    const files = await fsp.readdir(dir).catch(() => []);
    const out = [];
    for (const f of files) {
      if (!/\.jar(\.disabled)?$/i.test(f)) continue;
      const st = await fsp.stat(path.join(dir, f));
      out.push({ file: f, enabled: !f.endsWith('.disabled'), size: st.size });
    }
    return out.sort((a, b) => a.file.localeCompare(b.file));
  }

  async toggleMod(id, file) {
    const dir = path.join(this.paths.gameDir(id), 'mods');
    const from = path.join(dir, path.basename(file));
    const to = file.endsWith('.disabled') ? from.slice(0, -'.disabled'.length) : `${from}.disabled`;
    await fsp.rename(from, to);
  }

  progress(id, p) { this.emit('progress', { id, ...p }); }

  async withBusy(id, fn) {
    if (this.busy.has(id)) throw new Error('This instance is already busy.');
    this.busy.add(id);
    this.emit('instances-changed');
    try { return await fn(); } finally {
      this.busy.delete(id);
      this.progress(id, { label: '', done: 0, total: 0, finished: true });
      this.emit('instances-changed');
    }
  }

  // Make sure the loader is installed; returns the version id to launch.
  async ensureInstalled(inst) {
    if (inst.versionId && fs.existsSync(this.paths.versionJson(inst.versionId))) return inst.versionId;
    const versionId = await Loaders.install(this.paths, {
      type: inst.loader.type, mc: inst.mc, version: inst.loader.version,
      onProgress: (p) => this.progress(inst.id, p),
      onLog: (s) => this.appendLog(inst.id, s),
    });
    inst.versionId = versionId;
    await this.saveInstance(inst);
    return versionId;
  }

  appendLog(id, text) {
    if (!this.parsers.has(id)) this.parsers.set(id, new LogParser());
    const lines = this.parsers.get(id).push(text);
    if (!lines.length) return;
    const all = (this.logs.get(id) || []).concat(lines);
    this.logs.set(id, all.length > 6000 ? all.slice(-5000) : all);
    this.emit('log', { id, lines });
  }

  getLog(id) { return this.logs.get(id) || []; }

  async play(id, { server } = {}) {
    if (this.running.has(id)) throw new Error('This instance is already running.');
    return this.withBusy(id, async () => {
      const inst = await this.getInstance(id);
      const settings = await this.getSettings();
      this.logs.set(id, []);
      this.parsers.set(id, new LogParser());
      this.progress(id, { label: 'Signing in', done: 0, total: 1 });
      const account = await this.sessionForLaunch();
      const versionId = await this.ensureInstalled(inst);
      const memory = inst.memory || { min: settings.memoryMin, max: settings.memoryMax };
      const extra = `${settings.extraJvmArgs || ''} ${inst.extraJvmArgs || ''}`.trim().split(/\s+/).filter(Boolean);
      const started = Date.now();
      const child = await L.launch(this.paths, {
        versionId, gameDir: this.paths.gameDir(id), account, memory,
        preset: inst.preset || settings.preset, extraJvmArgs: extra,
        javaPath: inst.javaPath || settings.javaPath || null,
        server: server || inst.server || null,
        onProgress: (p) => this.progress(id, p),
        onLog: (s) => this.appendLog(id, s),
        onExit: async (code) => {
          this.running.delete(id);
          const fresh = await this.getInstance(id).catch(() => null);
          if (fresh) {
            fresh.playTime = (fresh.playTime || 0) + Math.round((Date.now() - started) / 1000);
            await this.saveInstance(fresh);
          }
          this.emit('game-exit', { id, code });
          this.emit('instances-changed');
        },
      });
      this.running.set(id, child);
      inst.lastPlayed = Date.now();
      await this.saveInstance(inst);
      this.emit('game-started', { id });
      return { started: true };
    });
  }

  kill(id) {
    const child = this.running.get(id);
    if (child) child.kill();
  }

  // ---------- content ----------
  async installModrinthPack(projectId, versionId, title) {
    const id = await this.newInstanceId(title || 'modpack');
    const inst = {
      id, name: title || 'Modpack', mc: null, loader: { type: 'vanilla', version: null }, versionId: null,
      created: Date.now(), lastPlayed: null, playTime: 0, installing: true,
      source: { type: 'modrinth', projectId },
    };
    await fsp.mkdir(this.paths.gameDir(id), { recursive: true });
    await this.saveInstance(inst);
    try {
      await this.withBusy(id, async () => {
        const info = await Modrinth.installModpack(projectId, versionId, this.paths.gameDir(id), this.paths.cache, {
          onProgress: (p) => this.progress(id, p),
        });
        Object.assign(inst, { mc: info.mc, loader: info.loader, source: { type: 'modrinth', ...info.modrinth } });
        delete inst.installing;
        await this.saveInstance(inst);
        await this.ensureInstalled(inst);
      });
    } catch (e) {
      inst.installError = e.message;
      delete inst.installing;
      await this.saveInstance(inst);
      throw e;
    }
    return inst;
  }

  async importMrpack(file) {
    const id = await this.newInstanceId(path.basename(file, '.mrpack'));
    const inst = { id, name: path.basename(file, '.mrpack'), mc: null, loader: { type: 'vanilla' }, versionId: null, created: Date.now(), installing: true };
    await fsp.mkdir(this.paths.gameDir(id), { recursive: true });
    await this.saveInstance(inst);
    return this.withBusy(id, async () => {
      const info = await Modrinth.installMrpack(file, this.paths.gameDir(id), { onProgress: (p) => this.progress(id, p) });
      Object.assign(inst, { name: info.name || inst.name, mc: info.mc, loader: info.loader, source: { type: 'mrpack' } });
      delete inst.installing;
      await this.saveInstance(inst);
      await this.ensureInstalled(inst);
      return inst;
    });
  }

  async addModToInstance(id, projectId, type = 'mod') {
    const inst = await this.getInstance(id);
    if (type === 'mod' && inst.loader.type === 'vanilla') throw new Error('Vanilla instances cannot load mods. Create one with a mod loader.');
    return this.withBusy(id, () => Modrinth.addMod(this.paths.gameDir(id), projectId, {
      mc: inst.mc, loader: inst.loader.type, type, onProgress: (p) => this.progress(id, p),
    }));
  }

  // ---------- misc ----------
  async minecraftVersions(includeSnapshots = false) {
    const m = await V.getManifest(this.paths);
    return m.versions.filter((v) => includeSnapshots || v.type === 'release').map((v) => ({ id: v.id, type: v.type }));
  }

  loaderVersions(type, mc) { return Loaders.listVersions(type, mc); }
  searchModrinth(q) { return Modrinth.search(q); }
  pingServer(host, port) { return ping(host, port); }
}

module.exports = { Manager, DEFAULT_SETTINGS };
