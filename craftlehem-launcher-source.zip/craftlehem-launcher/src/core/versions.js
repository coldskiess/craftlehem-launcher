'use strict';
// Minecraft version metadata: download version JSONs, merge loader profiles onto
// vanilla ("inheritsFrom"), and work out every library, native and asset needed.
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const AdmZip = require('adm-zip');
const { getJson, download, downloadAll, isValid } = require('./http');
const { allowed, osName, archName } = require('./rules');
const { mavenPath } = require('./paths');

const MANIFEST_URL = 'https://piston-meta.mojang.com/mc/game/version_manifest_v2.json';
const LIBRARIES_BASE = 'https://libraries.minecraft.net/';
const RESOURCES_BASE = 'https://resources.download.minecraft.net/';

let manifestCache = null;
async function getManifest(paths, { refresh = false } = {}) {
  const file = path.join(paths.cache, 'version_manifest_v2.json');
  if (!refresh && manifestCache) return manifestCache;
  try {
    manifestCache = await getJson(MANIFEST_URL);
    await fsp.writeFile(file, JSON.stringify(manifestCache));
  } catch (e) {
    // Offline: fall back to the last copy we saved.
    if (!fs.existsSync(file)) throw e;
    manifestCache = JSON.parse(await fsp.readFile(file, 'utf8'));
  }
  return manifestCache;
}

// Make sure versions/<id>/<id>.json exists (vanilla versions are fetched from Mojang).
async function ensureVersionJson(paths, id) {
  const file = paths.versionJson(id);
  const manifest = await getManifest(paths).catch(() => null);
  const entry = manifest && manifest.versions.find((v) => v.id === id);
  if (entry) {
    await download(entry.url, file, { sha1: entry.sha1 });
  } else if (!fs.existsSync(file)) {
    throw new Error(`Unknown Minecraft version "${id}"`);
  }
  return JSON.parse(await fsp.readFile(file, 'utf8'));
}

function libKey(name) {
  const [group, artifact, , classifier] = name.split('@')[0].split(':');
  return `${group}:${artifact}:${classifier || ''}`;
}

// Merge a child profile (Fabric/Forge/NeoForge) onto its parent (vanilla).
function mergeProfiles(parent, child) {
  const merged = { ...parent, ...child };
  merged.id = child.id;
  merged.jar = child.jar || parent.jar || undefined;
  const seen = new Set();
  merged.libraries = [];
  for (const lib of [...(child.libraries || []), ...(parent.libraries || [])]) {
    const key = libKey(lib.name);
    // Natives and rule-gated libs can share a key across OSes, so only dedupe plain ones.
    if (!lib.rules && !lib.natives) {
      if (seen.has(key)) continue;
      seen.add(key);
    }
    merged.libraries.push(lib);
  }
  if (parent.arguments || child.arguments) {
    merged.arguments = {
      game: [...((parent.arguments && parent.arguments.game) || []), ...((child.arguments && child.arguments.game) || [])],
      jvm: [...((parent.arguments && parent.arguments.jvm) || []), ...((child.arguments && child.arguments.jvm) || [])],
    };
  }
  merged.minecraftArguments = child.minecraftArguments || parent.minecraftArguments;
  for (const k of ['assetIndex', 'assets', 'downloads', 'javaVersion', 'logging']) {
    merged[k] = child[k] || parent[k];
  }
  delete merged.inheritsFrom;
  return merged;
}

async function resolveVersion(paths, id) {
  let json = await ensureVersionJson(paths, id);
  if (json.inheritsFrom) {
    const parent = await resolveVersion(paths, json.inheritsFrom);
    json = mergeProfiles(parent, json);
    json._baseId = parent._baseId || parent.id;
  } else {
    json._baseId = json.id;
  }
  return json;
}

// Work out what each library needs: a classpath jar, a natives jar to unpack, or both.
function planLibraries(paths, version, features = {}) {
  const os = osName();
  const classpath = [];
  const nativeJars = [];
  const jobs = [];
  const missingLocal = [];
  for (const lib of version.libraries || []) {
    if (!allowed(lib.rules, features)) continue;
    const dl = lib.downloads || {};

    // Old-style natives (pre-1.19): a classifier per OS that must be unpacked.
    if (lib.natives && lib.natives[os]) {
      const classifier = lib.natives[os].replace('${arch}', archName() === 'x64' || archName() === 'arm64' ? '64' : '32');
      const art = dl.classifiers && dl.classifiers[classifier];
      const rel = art ? art.path : mavenPath(`${lib.name}:${classifier}`);
      const dest = path.join(paths.libraries, rel);
      const url = art ? art.url : (lib.url || LIBRARIES_BASE) + rel;
      jobs.push({ url, dest, sha1: art && art.sha1, size: art && art.size });
      nativeJars.push({ file: dest, exclude: (lib.extract && lib.extract.exclude) || ['META-INF/'] });
      if (!dl.artifact) continue;
    }

    let rel, url, sha1, size;
    if (dl.artifact) {
      rel = dl.artifact.path || mavenPath(lib.name);
      url = dl.artifact.url;
      sha1 = dl.artifact.sha1;
      size = dl.artifact.size;
    } else if (!lib.natives) {
      rel = mavenPath(lib.name);
      url = (lib.url || LIBRARIES_BASE).replace(/\/?$/, '/') + rel;
      sha1 = lib.sha1;
      size = lib.size;
    } else {
      continue;
    }
    const dest = path.join(paths.libraries, rel);
    // Forge/NeoForge installers generate some jars locally and leave the URL empty.
    if (url) jobs.push({ url, dest, sha1, size });
    else missingLocal.push(dest);
    classpath.push(dest);
    // New-style natives (1.19+) sit on the classpath, but we also unpack them for java.library.path.
    if (/:natives-/.test(lib.name)) nativeJars.push({ file: dest, exclude: ['META-INF/'], onlyBinaries: true });
  }
  return { classpath, nativeJars, jobs, missingLocal };
}

async function extractNatives(nativeJars, dir) {
  await fsp.rm(dir, { recursive: true, force: true });
  await fsp.mkdir(dir, { recursive: true });
  for (const n of nativeJars) {
    if (!fs.existsSync(n.file)) continue;
    const zip = new AdmZip(n.file);
    for (const e of zip.getEntries()) {
      if (e.isDirectory) continue;
      if (n.exclude.some((x) => e.entryName.startsWith(x))) continue;
      if (n.onlyBinaries && !/\.(dll|so|dylib|jnilib)$/i.test(e.entryName)) continue;
      const out = path.join(dir, n.onlyBinaries ? path.basename(e.entryName) : e.entryName);
      if (!out.startsWith(dir)) continue; // zip-slip guard
      await fsp.mkdir(path.dirname(out), { recursive: true });
      await fsp.writeFile(out, e.getData());
    }
  }
}

async function planAssets(paths, version) {
  const idx = version.assetIndex;
  if (!idx) return { jobs: [], indexId: 'legacy' };
  const indexFile = path.join(paths.assets, 'indexes', `${idx.id}.json`);
  await download(idx.url, indexFile, { sha1: idx.sha1, size: idx.size });
  const index = JSON.parse(await fsp.readFile(indexFile, 'utf8'));
  const jobs = [];
  for (const [name, obj] of Object.entries(index.objects)) {
    const sub = obj.hash.slice(0, 2);
    jobs.push({
      url: `${RESOURCES_BASE}${sub}/${obj.hash}`,
      dest: path.join(paths.assets, 'objects', sub, obj.hash),
      sha1: obj.hash,
      size: obj.size,
      name,
    });
  }
  return { jobs, index, indexId: idx.id };
}

// Very old versions read assets from a "virtual" copy or the game's resources folder.
async function linkLegacyAssets(paths, assetPlan, gameDir) {
  const { index, indexId, jobs } = assetPlan;
  if (!index || !(index.virtual || index.map_to_resources)) return null;
  const target = index.map_to_resources ? path.join(gameDir, 'resources') : path.join(paths.assets, 'virtual', indexId);
  for (const j of jobs) {
    const out = path.join(target, j.name);
    if (await isValid(out, null, j.size)) continue;
    await fsp.mkdir(path.dirname(out), { recursive: true });
    await fsp.copyFile(j.dest, out);
  }
  return target;
}

// Like the official launcher, a loader version gets its own copy of the vanilla jar
// (versions/<loader-id>/<loader-id>.jar). Forge/NeoForge rely on that exact name to
// keep the vanilla jar off their module path.
async function prepareClientJar(paths, version) {
  const baseId = version.jar || version._baseId || version.id;
  const baseJar = paths.versionJar(baseId);
  const client = version.downloads && version.downloads.client;
  const jarFile = version.id === baseId ? baseJar : paths.versionJar(version.id);
  return {
    jarFile,
    baseJar,
    job: client ? { url: client.url, dest: baseJar, sha1: client.sha1, size: client.size } : null,
    async finalize() {
      if (jarFile === baseJar || !fs.existsSync(baseJar)) return;
      if (client && (await isValid(jarFile, client.sha1, client.size))) return;
      await fsp.mkdir(path.dirname(jarFile), { recursive: true });
      await fsp.copyFile(baseJar, jarFile);
    },
  };
}

async function prepareLogging(paths, version) {
  const log = version.logging && version.logging.client;
  if (!log || !log.file) return null;
  const file = path.join(paths.assets, 'log_configs', log.file.id);
  return { file, job: { url: log.file.url, dest: file, sha1: log.file.sha1, size: log.file.size }, argument: log.argument };
}

module.exports = {
  getManifest, ensureVersionJson, resolveVersion, mergeProfiles, planLibraries, extractNatives,
  planAssets, linkLegacyAssets, prepareClientJar, prepareLogging, downloadAll,
};
