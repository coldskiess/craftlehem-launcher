'use strict';
// Mod loaders. Fabric and Quilt publish ready-made launcher profiles. Forge and
// NeoForge ship an installer that patches Minecraft locally, so we run it headless.
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const { spawn } = require('child_process');
const AdmZip = require('adm-zip');
const { getJson, request, download } = require('../http');
const V = require('../versions');
const J = require('../java');

const NEOFORGE_MAVEN = 'https://maven.neoforged.net/releases/net/neoforged/neoforge';
const FORGE_MAVEN = 'https://maven.minecraftforge.net/net/minecraftforge/forge';

// Compare loader versions numerically ("0.16.10" > "0.16.9"); pre-releases sort below releases.
function cmpVersion(a, b) {
  const pa = a.split(/[.+-]/), pb = b.split(/[.+-]/);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const x = pa[i], y = pb[i];
    if (x === undefined) return /^\d/.test(y) ? -1 : 1;
    if (y === undefined) return /^\d/.test(x) ? 1 : -1;
    const nx = Number(x), ny = Number(y);
    if (!Number.isNaN(nx) && !Number.isNaN(ny)) { if (nx !== ny) return nx - ny; continue; }
    if (x !== y) return x < y ? -1 : 1;
  }
  return 0;
}

async function mavenVersions(base) {
  const res = await request(`${base}/maven-metadata.xml`);
  if (!res.ok) throw new Error(`Could not read loader versions (HTTP ${res.status})`);
  const xml = await res.text();
  return [...xml.matchAll(/<version>([^<]+)<\/version>/g)].map((m) => m[1]);
}

// NeoForge numbers its builds after the Minecraft version: MC 1.21.1 -> 21.1.x, MC 26.1 -> 26.1.x.
function neoforgePrefix(mc) {
  const p = mc.split('.');
  if (p[0] === '1') return `${p[1]}.${p[2] || 0}.`;
  return `${mc}.`;
}

async function listVersions(type, mc) {
  switch (type) {
    case 'fabric': {
      const list = await getJson(`https://meta.fabricmc.net/v2/versions/loader/${encodeURIComponent(mc)}`);
      return list.map((x) => ({ version: x.loader.version, stable: x.loader.stable }));
    }
    case 'quilt': {
      const list = await getJson(`https://meta.quiltmc.org/v3/versions/loader/${encodeURIComponent(mc)}`);
      return list.map((x) => ({ version: x.loader.version, stable: !/beta|alpha|pre/i.test(x.loader.version) }))
        .sort((a, b) => cmpVersion(b.version, a.version));
    }
    case 'neoforge': {
      const prefix = neoforgePrefix(mc);
      const all = (await mavenVersions(NEOFORGE_MAVEN)).filter((v) => v.startsWith(prefix));
      return all.reverse().map((v) => ({ version: v, stable: !/beta|alpha/i.test(v) }));
    }
    case 'forge': {
      const all = (await mavenVersions(FORGE_MAVEN)).filter((v) => v.startsWith(`${mc}-`));
      return all.map((v) => ({ version: v.slice(mc.length + 1), stable: true }));
    }
    default:
      return [];
  }
}

async function saveProfile(paths, profile) {
  const file = paths.versionJson(profile.id);
  await fsp.mkdir(path.dirname(file), { recursive: true });
  await fsp.writeFile(file, JSON.stringify(profile, null, 2));
  return profile.id;
}

function runInstaller(javaBin, args, cwd, onLog) {
  return new Promise((resolve, reject) => {
    const child = spawn(J.consoleJava(javaBin), args, { cwd, windowsHide: true });
    let tail = '';
    const take = (d) => {
      const s = String(d);
      tail = (tail + s).slice(-4000);
      onLog && onLog(s);
    };
    child.stdout.on('data', take);
    child.stderr.on('data', take);
    child.on('error', reject);
    child.on('exit', (code) => (code === 0 ? resolve() : reject(new Error(`Loader installer failed (exit ${code}):\n${tail}`))));
  });
}

async function installViaInstaller(paths, { url, flag, mc, onProgress, onLog }) {
  // The installer insists on a vanilla-launcher style folder.
  const profiles = path.join(paths.root, 'launcher_profiles.json');
  if (!fs.existsSync(profiles)) await fsp.writeFile(profiles, JSON.stringify({ profiles: {} }));

  onProgress && onProgress({ label: 'Downloading loader installer', done: 0, total: 1 });
  const installer = path.join(paths.cache, 'installers', path.basename(new URL(url).pathname));
  await download(url, installer);

  // Read the version id the installer will create, without running it.
  const zip = new AdmZip(installer);
  const versionEntry = zip.getEntry('version.json');
  if (!versionEntry) throw new Error('This installer is too old to install automatically.');
  const profile = JSON.parse(versionEntry.getData().toString('utf8'));
  if (fs.existsSync(paths.versionJson(profile.id)) && fs.existsSync(path.join(paths.versionDir(profile.id), '.craftlehem-installed'))) {
    return profile.id;
  }

  // Installers download vanilla themselves, but giving them our copy is faster and offline-safe.
  await V.ensureVersionJson(paths, mc);
  const vanilla = await V.resolveVersion(paths, mc);
  const client = await V.prepareClientJar(paths, vanilla);
  if (client.job) await download(client.job.url, client.job.dest, client.job);
  const javaBin = await J.ensureRuntime(paths, J.componentFor(vanilla), onProgress);

  onProgress && onProgress({ label: 'Installing loader (this takes a minute)', done: 0, total: 1 });
  await runInstaller(javaBin, ['-jar', installer, flag, paths.root], paths.root, onLog);
  if (!fs.existsSync(paths.versionJson(profile.id))) throw new Error(`Installer finished but ${profile.id} was not created.`);
  await fsp.writeFile(path.join(paths.versionDir(profile.id), '.craftlehem-installed'), String(Date.now()));
  return profile.id;
}

// Install a loader for a Minecraft version and return the launchable version id.
async function install(paths, { type, mc, version, onProgress, onLog }) {
  if (!type || type === 'vanilla') {
    await V.ensureVersionJson(paths, mc);
    return mc;
  }
  if (!version) {
    const list = await listVersions(type, mc);
    const pick = list.find((v) => v.stable) || list[0];
    if (!pick) throw new Error(`No ${type} version is available for Minecraft ${mc}.`);
    version = pick.version;
  }
  await V.ensureVersionJson(paths, mc);
  switch (type) {
    case 'fabric':
      return saveProfile(paths, await getJson(`https://meta.fabricmc.net/v2/versions/loader/${mc}/${version}/profile/json`));
    case 'quilt':
      return saveProfile(paths, await getJson(`https://meta.quiltmc.org/v3/versions/loader/${mc}/${version}/profile/json`));
    case 'neoforge':
      return installViaInstaller(paths, {
        url: `${NEOFORGE_MAVEN}/${version}/neoforge-${version}-installer.jar`, flag: '--install-client', mc, onProgress, onLog,
      });
    case 'forge':
      return installViaInstaller(paths, {
        url: `${FORGE_MAVEN}/${mc}-${version}/forge-${mc}-${version}-installer.jar`, flag: '--installClient', mc, onProgress, onLog,
      });
    default:
      throw new Error(`Unknown loader "${type}"`);
  }
}

module.exports = { listVersions, install, neoforgePrefix, cmpVersion };
