'use strict';
// Turn a resolved version + instance + account into a running game.
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const V = require('./versions');
const J = require('./java');
const { allowed } = require('./rules');
const { downloadAll } = require('./http');

const LAUNCHER_NAME = 'craftlehem-launcher';
const LAUNCHER_VERSION = '0.1.0';

// JVM flag presets. "optimized" is tuned G1 (Aikar-style, minus server-only flags);
// "zgc" is generational ZGC, which needs Java 21+ and trades some throughput for
// near-zero GC pauses. Big modpacks usually feel smoothest on one of these two.
const JVM_PRESETS = {
  optimized: {
    label: 'Optimized (tuned G1)',
    flags: [
      '-XX:+UseG1GC', '-XX:+ParallelRefProcEnabled', '-XX:MaxGCPauseMillis=130', '-XX:+UnlockExperimentalVMOptions',
      '-XX:+DisableExplicitGC', '-XX:G1NewSizePercent=30', '-XX:G1MaxNewSizePercent=40', '-XX:G1HeapRegionSize=16M',
      '-XX:G1ReservePercent=20', '-XX:G1HeapWastePercent=5', '-XX:G1MixedGCCountTarget=4',
      '-XX:InitiatingHeapOccupancyPercent=15', '-XX:G1MixedGCLiveThresholdPercent=90',
      '-XX:G1RSetUpdatingPauseTimePercent=5', '-XX:SurvivorRatio=32', '-XX:+PerfDisableSharedMem',
      '-XX:MaxTenuringThreshold=1',
    ],
  },
  zgc: {
    label: 'Low pause (generational ZGC, Java 21+)',
    minJava: 21,
    flags: ['-XX:+UseZGC', '-XX:+ZGenerational', '-XX:+DisableExplicitGC', '-XX:+PerfDisableSharedMem'],
  },
  vanilla: { label: 'Java defaults', flags: [] },
};

function offlineUuid(name) {
  const h = crypto.createHash('md5').update(`OfflinePlayer:${name}`).digest();
  h[6] = (h[6] & 0x0f) | 0x30;
  h[8] = (h[8] & 0x3f) | 0x80;
  return h.toString('hex');
}

function fill(str, vars) {
  return str.replace(/\$\{([a-zA-Z0-9_]+)\}/g, (m, k) => (k in vars ? vars[k] : m));
}

function collectArgs(list, features, vars) {
  const out = [];
  for (const a of list || []) {
    if (typeof a === 'string') { out.push(fill(a, vars)); continue; }
    if (!allowed(a.rules, features)) continue;
    const v = Array.isArray(a.value) ? a.value : [a.value];
    for (const s of v) out.push(fill(s, vars));
  }
  return out;
}

function javaMajor(versionString) {
  if (!versionString) return 0;
  const p = versionString.split('.');
  return p[0] === '1' ? Number(p[1]) : Number(p[0]);
}

// Download everything the version needs. Safe to call every launch: files that are
// already present and match their checksum are skipped.
async function prepare(paths, versionId, { onProgress, features = {} } = {}) {
  onProgress && onProgress({ label: 'Reading version info', done: 0, total: 1 });
  const version = await V.resolveVersion(paths, versionId);

  const libs = V.planLibraries(paths, version, features);
  const client = await V.prepareClientJar(paths, version);
  const logging = await V.prepareLogging(paths, version);
  const jobs = [...libs.jobs];
  if (client.job) jobs.push(client.job);
  if (logging) jobs.push(logging.job);
  await downloadAll(jobs, { onProgress, label: 'Downloading libraries' });
  await client.finalize();

  const missing = libs.missingLocal.filter((f) => !fs.existsSync(f));
  if (missing.length) throw new Error(`Loader files are missing (reinstall the loader):\n${missing.slice(0, 3).join('\n')}`);

  const assets = await V.planAssets(paths, version);
  await downloadAll(assets.jobs, { onProgress, concurrency: 32, label: 'Downloading assets' });

  const javaBin = await J.ensureRuntime(paths, J.componentFor(version), onProgress);
  return { version, libs, client, logging, assets, javaBin };
}

async function launch(paths, opts) {
  const {
    versionId, gameDir, account, memory = { min: 1024, max: 4096 }, preset = 'optimized', extraJvmArgs = [],
    javaPath, resolution, server, onProgress, onLog, onExit, detached = false,
  } = opts;
  await fsp.mkdir(gameDir, { recursive: true });

  const features = { has_custom_resolution: Boolean(resolution), is_quick_play_multiplayer: Boolean(server) };
  const prep = await prepare(paths, versionId, { onProgress, features });
  const { version, libs, client, logging, assets } = prep;
  const javaBin = javaPath || prep.javaBin;

  onProgress && onProgress({ label: 'Unpacking natives', done: 0, total: 1 });
  const nativesDir = path.join(paths.natives, version.id);
  await V.extractNatives(libs.nativeJars, nativesDir);
  const legacyAssetsDir = await V.linkLegacyAssets(paths, assets, gameDir);

  const sep = process.platform === 'win32' ? ';' : ':';
  const cp = [...new Set([...libs.classpath, client.jarFile])].filter((f) => fs.existsSync(f));

  const name = account.name;
  const vars = {
    auth_player_name: name,
    version_name: version.id,
    game_directory: gameDir,
    assets_root: paths.assets,
    game_assets: legacyAssetsDir || paths.assets,
    assets_index_name: assets.indexId,
    auth_uuid: account.uuid || offlineUuid(name),
    auth_access_token: account.accessToken || '0',
    auth_session: account.accessToken || '0',
    clientid: account.clientId || '',
    auth_xuid: account.xuid || '',
    user_type: account.type === 'msa' ? 'msa' : 'legacy',
    user_properties: '{}',
    version_type: version.type || 'release',
    natives_directory: nativesDir,
    launcher_name: LAUNCHER_NAME,
    launcher_version: LAUNCHER_VERSION,
    classpath: cp.join(sep),
    classpath_separator: sep,
    library_directory: paths.libraries,
    resolution_width: resolution ? String(resolution.width) : '854',
    resolution_height: resolution ? String(resolution.height) : '480',
    quickPlayMultiplayer: server ? `${server.host}:${server.port || 25565}` : '',
    quickPlayPath: 'quickPlay/log.json',
  };

  // JVM arguments
  const jvm = [`-Xms${memory.min}M`, `-Xmx${memory.max}M`];
  const major = javaMajor(await J.javaVersionOf(javaBin));
  let presetDef = JVM_PRESETS[preset] || JVM_PRESETS.optimized;
  if (presetDef.minJava && major && major < presetDef.minJava) presetDef = JVM_PRESETS.optimized;
  jvm.push(...presetDef.flags);
  if (version.arguments && version.arguments.jvm) {
    jvm.push(...collectArgs(version.arguments.jvm, features, vars));
  } else {
    jvm.push(`-Djava.library.path=${nativesDir}`, '-cp', vars.classpath);
  }
  if (logging && logging.argument) jvm.push(fill(logging.argument, { path: logging.file }));
  jvm.push(...extraJvmArgs);

  // Game arguments
  let game;
  if (version.arguments && version.arguments.game) {
    game = collectArgs(version.arguments.game, features, vars);
  } else {
    game = fill(version.minecraftArguments || '', vars).split(' ').filter(Boolean);
    if (resolution) game.push('--width', vars.resolution_width, '--height', vars.resolution_height);
  }
  // Versions before quick play (1.20) join a server with --server/--port instead.
  if (server && !game.includes('--quickPlayMultiplayer')) game.push('--server', server.host, '--port', String(server.port || 25565));

  const args = [...jvm, version.mainClass, ...game];
  const safeArgs = args.map((a) => (a === vars.auth_access_token && a !== '0' ? '<access token hidden>' : a));
  onLog && onLog(`[Craftlehem] Java: ${javaBin}\n[Craftlehem] Launching ${version.id} with ${presetDef.label}\n`);
  onLog && onLog(`[Craftlehem] Command: ${safeArgs.join(' ')}\n`);
  onProgress && onProgress({ label: 'Starting Minecraft', done: 1, total: 1 });

  const child = spawn(javaBin, args, { cwd: gameDir, detached, windowsHide: false });
  child.stdout.on('data', (d) => onLog && onLog(String(d)));
  child.stderr.on('data', (d) => onLog && onLog(String(d)));
  child.on('exit', (code) => onExit && onExit(code));
  child.on('error', (e) => { onLog && onLog(`[Craftlehem] Failed to start Java: ${e.message}\n`); onExit && onExit(-1); });
  return child;
}

module.exports = { launch, prepare, offlineUuid, JVM_PRESETS, javaMajor };
