'use strict';
// Microsoft account login for Minecraft: Microsoft OAuth (device code) -> Xbox Live
// -> XSTS -> Minecraft Services. Needs an Azure app ID approved by Mojang
// (https://aka.ms/mce-reviewappid); until then Minecraft returns "Invalid app registration".
const { postJson, postForm, getJson, sleep } = require('../http');

const MS_BASE = 'https://login.microsoftonline.com/consumers/oauth2/v2.0';
const SCOPE = 'XboxLive.signin offline_access';

const XSTS_ERRORS = {
  2148916233: 'This Microsoft account has no Xbox profile yet. Sign in once at minecraft.net, then try again.',
  2148916235: 'Xbox Live is not available in your country.',
  2148916236: 'This account needs adult verification on the Xbox website (South Korea).',
  2148916237: 'This account needs adult verification on the Xbox website (South Korea).',
  2148916238: 'This is a child account. An adult must add it to a Microsoft Family before it can play.',
};

class AuthError extends Error {}

// Step 1: ask Microsoft for a short code the player types at microsoft.com/link.
async function startDeviceCode(clientId) {
  if (!clientId) throw new AuthError('No Microsoft app ID is set. Add one in Settings > Accounts.');
  const r = await postForm(`${MS_BASE}/devicecode`, { client_id: clientId, scope: SCOPE });
  if (!r.ok) throw new AuthError(r.data.error_description || `Microsoft refused the login request (${r.status}).`);
  return {
    userCode: r.data.user_code,
    verificationUri: r.data.verification_uri,
    deviceCode: r.data.device_code,
    interval: r.data.interval || 5,
    expiresAt: Date.now() + (r.data.expires_in || 900) * 1000,
    message: r.data.message,
  };
}

// Step 2: wait while the player approves the login in their browser.
async function pollDeviceCode(clientId, dc, { isCancelled } = {}) {
  let interval = dc.interval;
  while (Date.now() < dc.expiresAt) {
    if (isCancelled && isCancelled()) throw new AuthError('Login cancelled.');
    await sleep(interval * 1000);
    const r = await postForm(`${MS_BASE}/token`, {
      grant_type: 'urn:ietf:params:oauth:grant-type:device_code', client_id: clientId, device_code: dc.deviceCode,
    });
    if (r.ok) return r.data;
    const err = r.data.error;
    if (err === 'authorization_pending') continue;
    if (err === 'slow_down') { interval += 5; continue; }
    if (err === 'expired_token') break;
    throw new AuthError(r.data.error_description || `Microsoft login failed (${err}).`);
  }
  throw new AuthError('The login code expired. Please try again.');
}

async function refreshMicrosoft(clientId, refreshToken) {
  const r = await postForm(`${MS_BASE}/token`, {
    grant_type: 'refresh_token', client_id: clientId, refresh_token: refreshToken, scope: SCOPE,
  });
  if (!r.ok) throw new AuthError('Your Microsoft login expired. Please sign in again.');
  return r.data;
}

// Steps 3-6: turn a Microsoft token into a Minecraft session and profile.
async function minecraftFromMicrosoft(msAccessToken) {
  const xbl = await postJson('https://user.auth.xboxlive.com/user/authenticate', {
    Properties: { AuthMethod: 'RPS', SiteName: 'user.auth.xboxlive.com', RpsTicket: `d=${msAccessToken}` },
    RelyingParty: 'http://auth.xboxlive.com', TokenType: 'JWT',
  });
  let xsts;
  try {
    xsts = await postJson('https://xsts.auth.xboxlive.com/xsts/authorize', {
      Properties: { SandboxId: 'RETAIL', UserTokens: [xbl.Token] },
      RelyingParty: 'rp://api.minecraftservices.com/', TokenType: 'JWT',
    });
  } catch (e) {
    const code = e.data && e.data.XErr;
    throw new AuthError(XSTS_ERRORS[code] || `Xbox Live sign-in failed${code ? ` (${code})` : ''}.`);
  }
  const uhs = xsts.DisplayClaims.xui[0].uhs;

  let mc;
  try {
    mc = await postJson('https://api.minecraftservices.com/authentication/login_with_xbox', {
      identityToken: `XBL3.0 x=${uhs};${xsts.Token}`,
    });
  } catch (e) {
    if (e.status === 403) {
      throw new AuthError('Minecraft rejected this launcher\'s app ID. It must be approved by Mojang first (aka.ms/mce-reviewappid).');
    }
    throw new AuthError(`Minecraft login failed (${e.status || e.message}).`);
  }
  const auth = { Authorization: `Bearer ${mc.access_token}` };

  let profile;
  try {
    profile = await getJson('https://api.minecraftservices.com/minecraft/profile', { headers: auth });
  } catch {
    const ent = await getJson('https://api.minecraftservices.com/entitlements/mcstore', { headers: auth }).catch(() => ({ items: [] }));
    if (!ent.items || !ent.items.length) throw new AuthError('This Microsoft account does not own Minecraft: Java Edition.');
    throw new AuthError('This account owns Minecraft but has no profile yet. Open the official launcher once to pick a username.');
  }
  return {
    type: 'msa',
    uuid: profile.id,
    name: profile.name,
    accessToken: mc.access_token,
    expiresAt: Date.now() + (mc.expires_in || 86400) * 1000,
    xuid: (xsts.DisplayClaims.xui[0] || {}).xid || '',
    skin: ((profile.skins || []).find((s) => s.state === 'ACTIVE') || {}).url || null,
  };
}

// Full login: returns the account plus the Microsoft refresh token to store (encrypted).
async function login(clientId, { onCode, isCancelled } = {}) {
  const dc = await startDeviceCode(clientId);
  onCode && onCode(dc);
  const ms = await pollDeviceCode(clientId, dc, { isCancelled });
  const account = await minecraftFromMicrosoft(ms.access_token);
  return { account, refreshToken: ms.refresh_token };
}

// Silent re-login before launching, using the stored refresh token.
async function refresh(clientId, refreshToken) {
  const ms = await refreshMicrosoft(clientId, refreshToken);
  const account = await minecraftFromMicrosoft(ms.access_token);
  return { account, refreshToken: ms.refresh_token || refreshToken };
}

module.exports = { login, refresh, startDeviceCode, AuthError };
