'use strict';
// Folder layout. Game files (versions, libraries, assets, Java) are shared by all
// instances so a second NeoForge 1.21.1 pack does not download everything again.
const path = require('path');
const fs = require('fs');

class Paths {
  constructor(root) {
    this.root = root;
    this.versions = path.join(root, 'versions');
    this.libraries = path.join(root, 'libraries');
    this.assets = path.join(root, 'assets');
    this.runtimes = path.join(root, 'runtimes');
    this.instances = path.join(root, 'instances');
    this.cache = path.join(root, 'cache');
    this.natives = path.join(root, 'natives');
    for (const d of [root, this.versions, this.libraries, this.assets, this.runtimes, this.instances, this.cache, this.natives]) {
      fs.mkdirSync(d, { recursive: true });
    }
  }
  versionDir(id) { return path.join(this.versions, id); }
  versionJson(id) { return path.join(this.versions, id, `${id}.json`); }
  versionJar(id) { return path.join(this.versions, id, `${id}.jar`); }
  instanceDir(id) { return path.join(this.instances, id); }
  gameDir(id) { return path.join(this.instances, id, 'minecraft'); }
}

// "group:artifact:version[:classifier][@ext]" -> relative maven path
function mavenPath(name) {
  let ext = 'jar';
  let coords = name;
  const at = coords.indexOf('@');
  if (at >= 0) { ext = coords.slice(at + 1); coords = coords.slice(0, at); }
  const [group, artifact, version, classifier] = coords.split(':');
  const file = `${artifact}-${version}${classifier ? `-${classifier}` : ''}.${ext}`;
  return [...group.split('.'), artifact, version, file].join('/');
}

module.exports = { Paths, mavenPath };
