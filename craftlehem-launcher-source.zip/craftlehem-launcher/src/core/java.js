'use strict';
// Java runtimes: use Mojang's official builds (the same ones the vanilla launcher
// downloads), picked per Minecraft version, so players never have to install Java.
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const { execFile } = require('child_process');
const { getJson, downloadAll } = require('./http');

const ALL_RUNTIMES = 'https://launchermeta.mojang.com/v1/products/java-runtime/2ec0cc96c44e5a76b9c8b7c39df7210883d12871/all.json';

function platformKey() {
  const a = process.arch;
  if (process.platform === 'win32') return a === 'arm64' ? 'windows-arm64' : a === 'ia32' ? 'windows-x86' : 'windows-x64';
  if (process.platform === 'darwin') return a === 'arm64' ? 'mac-os-arm64' : 'mac-os';
  return a === 'ia32' ? 'linux-i386' : 'linux';
}

function javaBinary(home) {
  if (process.platform === 'win32') return path.join(home, 'bin', 'javaw.exe');
  if (process.platform === 'darwin') {
    const mac = path.join(home, 'jre.bundle', 'Contents', 'Home', 'bin', 'java');
    if (fs.existsSync(mac)) return mac;
  }
  return path.join(home, 'bin', 'java');
}

// For command-line tools (installers) we want java.exe, not javaw.exe, so output is visible.
function consoleJava(bin) {
  return process.platform === 'win32' ? bin.replace(/javaw\.exe$/i, 'java.exe') : bin;
}

async function ensureRuntime(paths, component = 'java-runtime-delta', onProgress) {
  const home = path.join(paths.runtimes, component);
  const marker = path.join(home, '.craftlehem-complete');
  const bin = javaBinary(home);
  if (fs.existsSync(marker) && fs.existsSync(bin)) return bin;

  const all = await getJson(ALL_RUNTIMES);
  const list = (all[platformKey()] || {})[component];
  if (!list || !list.length) throw new Error(`Mojang has no ${component} Java runtime for ${platformKey()}`);
  const manifest = await getJson(list[0].manifest.url);

  const jobs = [];
  const execs = [];
  const links = [];
  for (const [rel, f] of Object.entries(manifest.files)) {
    const dest = path.join(home, rel);
    if (f.type === 'directory') { await fsp.mkdir(dest, { recursive: true }); continue; }
    if (f.type === 'link') { links.push({ dest, target: f.target }); continue; }
    const raw = f.downloads.raw;
    jobs.push({ url: raw.url, dest, sha1: raw.sha1, size: raw.size });
    if (f.executable) execs.push(dest);
  }
  await downloadAll(jobs, { concurrency: 24, onProgress, label: `Downloading Java (${component})` });
  if (process.platform !== 'win32') {
    for (const e of execs) await fsp.chmod(e, 0o755);
    for (const l of links) {
      await fsp.rm(l.dest, { force: true });
      await fsp.symlink(l.target, l.dest).catch(() => {});
    }
  }
  await fsp.writeFile(marker, JSON.stringify({ component, version: list[0].version, at: Date.now() }));
  return bin;
}

function javaVersionOf(bin) {
  return new Promise((resolve) => {
    execFile(consoleJava(bin), ['-version'], { timeout: 15000 }, (err, stdout, stderr) => {
      const m = /version "([^"]+)"/.exec(String(stderr) + String(stdout));
      resolve(err && !m ? null : m && m[1]);
    });
  });
}

// Pick the runtime a version asks for; very old versions without the field get Java 8.
function componentFor(version) {
  return (version.javaVersion && version.javaVersion.component) || 'jre-legacy';
}

module.exports = { ensureRuntime, componentFor, javaVersionOf, consoleJava, platformKey };
