'use strict';
// Minecraft "Server List Ping": the same request the multiplayer menu makes, so the
// launcher can show if a server is online, its player count and its MOTD.
const net = require('net');
const dns = require('dns').promises;

function varInt(n) {
  const out = [];
  do {
    let b = n & 0x7f;
    n >>>= 7;
    if (n !== 0) b |= 0x80;
    out.push(b);
  } while (n !== 0);
  return Buffer.from(out);
}

function readVarInt(buf, offset) {
  let value = 0, size = 0, b;
  do {
    if (offset + size >= buf.length) return null;
    b = buf[offset + size];
    value |= (b & 0x7f) << (7 * size);
    size++;
    if (size > 5) throw new Error('VarInt too big');
  } while (b & 0x80);
  return { value, size };
}

function packet(id, payload) {
  const body = Buffer.concat([varInt(id), payload]);
  return Buffer.concat([varInt(body.length), body]);
}

function mcString(s) {
  const b = Buffer.from(s, 'utf8');
  return Buffer.concat([varInt(b.length), b]);
}

// Flatten a chat component into plain text with § colour codes stripped.
function motdText(desc) {
  if (!desc) return '';
  if (typeof desc === 'string') return desc.replace(/§./g, '');
  let s = desc.text || '';
  for (const e of desc.extra || []) s += motdText(e);
  return s.replace(/§./g, '');
}

async function resolve(host, port) {
  if (port && port !== 25565) return { host, port };
  try {
    const srv = await dns.resolveSrv(`_minecraft._tcp.${host}`);
    if (srv.length) return { host: srv[0].name, port: srv[0].port };
  } catch { /* no SRV record */ }
  return { host, port: port || 25565 };
}

async function ping(address, port = 25565, timeout = 5000) {
  const target = await resolve(address, port);
  return new Promise((resolvePromise) => {
    const started = Date.now();
    const sock = net.createConnection({ host: target.host, port: target.port });
    let data = Buffer.alloc(0);
    const done = (result) => { sock.destroy(); resolvePromise(result); };
    sock.setTimeout(timeout, () => done({ online: false, error: 'timed out' }));
    sock.on('error', (e) => done({ online: false, error: e.code || e.message }));
    sock.on('connect', () => {
      const portBuf = Buffer.alloc(2);
      portBuf.writeUInt16BE(target.port);
      // Handshake (protocol -1 = "just asking"), next state 1 = status.
      sock.write(packet(0x00, Buffer.concat([varInt(767), mcString(address), portBuf, varInt(1)])));
      sock.write(packet(0x00, Buffer.alloc(0)));
    });
    sock.on('data', (chunk) => {
      data = Buffer.concat([data, chunk]);
      const len = readVarInt(data, 0);
      if (!len || data.length < len.size + len.value) return;
      try {
        let o = len.size;
        const id = readVarInt(data, o); o += id.size;
        const strLen = readVarInt(data, o); o += strLen.size;
        const json = JSON.parse(data.slice(o, o + strLen.value).toString('utf8'));
        done({
          online: true,
          latency: Date.now() - started,
          players: json.players ? { online: json.players.online, max: json.players.max, sample: (json.players.sample || []).map((p) => p.name) } : null,
          version: json.version ? json.version.name : '',
          motd: motdText(json.description),
          favicon: json.favicon || null,
        });
      } catch (e) {
        done({ online: false, error: `bad response: ${e.message}` });
      }
    });
  });
}

module.exports = { ping };
