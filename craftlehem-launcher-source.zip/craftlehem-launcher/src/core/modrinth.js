'use strict';
// Modrinth: search mods/modpacks, add mods (with required dependencies) to an
// instance, and install .mrpack modpacks.
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const AdmZip = require('adm-zip');
const { getJson, download, downloadAll } = require('./http');

const API = 'https://api.modrinth.com/v2';

async function search({ query = '', type = 'modpack', mc, loader, offset = 0, limit = 20, sort = 'relevance' } = {}) {
  const facets = [[`project_type:${type}`]];
  if (mc) facets.push([`versions:${mc}`]);
  if (loader && type === 'mod') facets.push([`categories:${loader}`]);
  const qs = new URLSearchParams({ query, offset: String(offset), limit: String(limit), index: sort, facets: JSON.stringify(facets) });
  const r = await getJson(`${API}/search?${qs}`);
  return {
    total: r.total_hits,
    hits: r.hits.map((h) => ({
      id: h.project_id, slug: h.slug, title: h.title, description: h.description, author: h.author,
      icon: h.icon_url, downloads: h.downloads, follows: h.follows, versions: h.versions,
      categories: h.display_categories || h.categories, type: h.project_type,
    })),
  };
}

async function project(idOrSlug) {
  return getJson(`${API}/project/${encodeURIComponent(idOrSlug)}`);
}

async function versions(idOrSlug, { mc, loader } = {}) {
  const qs = new URLSearchParams();
  if (mc) qs.set('game_versions', JSON.stringify([mc]));
  if (loader) qs.set('loaders', JSON.stringify([loader]));
  return getJson(`${API}/project/${encodeURIComponent(idOrSlug)}/version?${qs}`);
}

function primaryFile(version) {
  return version.files.find((f) => f.primary) || version.files[0];
}

// Where each kind of Modrinth project goes inside the game folder.
const FOLDERS = { mod: 'mods', shader: 'shaderpacks', resourcepack: 'resourcepacks', datapack: 'datapacks' };

// Add a project (mod, shader or resource pack) to an instance, plus any required mods.
async function addMod(gameDir, projectId, { mc, loader, type = 'mod', onProgress, _seen = new Set() } = {}) {
  if (_seen.has(projectId)) return [];
  _seen.add(projectId);
  const list = await versions(projectId, { mc, loader: type === 'mod' ? loader : undefined });
  const v = list.find((x) => x.version_type === 'release') || list[0];
  if (!v) throw new Error(type === 'mod' ? `No version of this mod supports ${loader} ${mc}.` : `No version supports Minecraft ${mc}.`);
  const file = primaryFile(v);
  const dir = path.join(gameDir, FOLDERS[type] || 'mods');
  onProgress && onProgress({ label: `Downloading ${file.filename}`, done: 0, total: 1 });
  await download(file.url, path.join(dir, file.filename), { sha1: file.hashes.sha1, size: file.size });
  const added = [file.filename];
  if (type === 'mod') {
    for (const dep of v.dependencies || []) {
      if (dep.dependency_type !== 'required' || !dep.project_id) continue;
      added.push(...(await addMod(gameDir, dep.project_id, { mc, loader, type, onProgress, _seen })));
    }
  }
  return added;
}

const LOADER_KEYS = { 'fabric-loader': 'fabric', 'quilt-loader': 'quilt', neoforge: 'neoforge', forge: 'forge' };

// Install a .mrpack into gameDir. Returns { mc, loader: {type, version}, name }.
async function installMrpack(mrpackFile, gameDir, { onProgress } = {}) {
  const zip = new AdmZip(mrpackFile);
  const indexEntry = zip.getEntry('modrinth.index.json');
  if (!indexEntry) throw new Error('This is not a Modrinth modpack (.mrpack).');
  const index = JSON.parse(indexEntry.getData().toString('utf8'));
  const root = path.resolve(gameDir);

  const jobs = [];
  for (const f of index.files || []) {
    if (f.env && f.env.client === 'unsupported') continue;
    const dest = path.resolve(root, f.path);
    if (!dest.startsWith(root + path.sep)) continue; // never write outside the instance
    jobs.push({ url: f.downloads[0], dest, sha1: f.hashes && f.hashes.sha1, size: f.fileSize });
  }
  await downloadAll(jobs, { onProgress, label: 'Downloading modpack files' });

  // overrides/ then client-overrides/ are copied over the game folder.
  for (const prefix of ['overrides/', 'client-overrides/']) {
    for (const e of zip.getEntries()) {
      if (e.isDirectory || !e.entryName.startsWith(prefix)) continue;
      const out = path.resolve(root, e.entryName.slice(prefix.length));
      if (!out.startsWith(root + path.sep)) continue;
      await fsp.mkdir(path.dirname(out), { recursive: true });
      await fsp.writeFile(out, e.getData());
    }
  }

  const deps = index.dependencies || {};
  let loader = { type: 'vanilla', version: null };
  for (const [k, type] of Object.entries(LOADER_KEYS)) {
    if (deps[k]) { loader = { type, version: deps[k] }; break; }
  }
  return { mc: deps.minecraft, loader, name: index.name, version: index.versionId };
}

// Download a modpack version from Modrinth and install it.
async function installModpack(projectId, versionId, gameDir, cacheDir, { onProgress } = {}) {
  const list = await versions(projectId);
  const v = versionId ? list.find((x) => x.id === versionId) : list.find((x) => x.version_type === 'release') || list[0];
  if (!v) throw new Error('No downloadable version of this modpack was found.');
  const file = primaryFile(v);
  const dest = path.join(cacheDir, 'modpacks', file.filename);
  onProgress && onProgress({ label: 'Downloading modpack', done: 0, total: 1 });
  await download(file.url, dest, { sha1: file.hashes.sha1, size: file.size });
  const info = await installMrpack(dest, gameDir, { onProgress });
  return { ...info, modrinth: { projectId, versionId: v.id, versionNumber: v.version_number } };
}

module.exports = { search, project, versions, addMod, installMrpack, installModpack };
