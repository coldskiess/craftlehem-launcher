'use strict';
const { contextBridge, ipcRenderer } = require('electron');

const EVENTS = ['progress', 'log', 'login-code', 'instances-changed', 'game-started', 'game-exit'];

contextBridge.exposeInMainWorld('launcher', {
  // Call a launcher action. Resolves with the value or rejects with a readable error.
  async call(method, ...args) {
    const r = await ipcRenderer.invoke('call', method, args);
    if (!r.ok) throw new Error(r.error);
    return r.value;
  },
  system: (what, arg) => ipcRenderer.invoke('system', what, arg),
  on(event, fn) {
    if (!EVENTS.includes(event)) return () => {};
    const h = (_e, d) => fn(d);
    ipcRenderer.on(event, h);
    return () => ipcRenderer.removeListener(event, h);
  },
});
