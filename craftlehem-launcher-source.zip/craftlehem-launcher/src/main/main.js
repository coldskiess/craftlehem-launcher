'use strict';
const path = require('path');
const os = require('os');
const { app, BrowserWindow, ipcMain, shell, dialog, safeStorage, Menu } = require('electron');
const { Manager } = require('../core/manager');
const { JVM_PRESETS } = require('../core/launch');
const PKG = require('../../package.json');

// One copy of the launcher at a time; a second launch just focuses the first window.
if (!app.requestSingleInstanceLock()) app.quit();

const DATA_ROOT = process.env.CRAFTLEHEM_DATA || path.join(app.getPath('appData'), 'CraftlehemLauncher');

let win = null;
let manager = null;

function createWindow() {
  win = new BrowserWindow({
    width: 1240,
    height: 780,
    minWidth: 980,
    minHeight: 640,
    frame: false,
    backgroundColor: '#09080c',
    title: 'Craftlehem Launcher',
    icon: path.join(__dirname, '..', 'renderer', 'assets', 'icon.png'),
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  Menu.setApplicationMenu(null);
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
  win.once('ready-to-show', () => win.show());
  // Links open in the real browser, never inside the launcher.
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https:\/\//.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e) => e.preventDefault());
}

function send(channel, data) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, data);
}

const crypto = {
  encrypt: (s) => (safeStorage.isEncryptionAvailable() ? `enc:${safeStorage.encryptString(s).toString('base64')}` : `raw:${s}`),
  decrypt: (s) => {
    if (s.startsWith('enc:')) return safeStorage.decryptString(Buffer.from(s.slice(4), 'base64'));
    return s.replace(/^raw:/, '');
  },
};

// Only these Manager methods can be called from the window.
const API = [
  'getSettings', 'saveSettings', 'listAccounts', 'selectAccount', 'removeAccount', 'loginMicrosoft', 'cancelLogin',
  'addOfflineAccount', 'listInstances', 'getInstance', 'createInstance', 'updateInstance', 'deleteInstance',
  'listMods', 'toggleMod', 'play', 'kill', 'getLog', 'installModrinthPack', 'addModToInstance',
  'minecraftVersions', 'loaderVersions', 'searchModrinth', 'pingServer',
];

app.whenReady().then(() => {
  manager = new Manager(DATA_ROOT, crypto);
  for (const ev of ['progress', 'log', 'login-code', 'instances-changed', 'game-started', 'game-exit']) {
    manager.on(ev, (d) => send(ev, d));
  }
  manager.on('game-started', async () => {
    const s = await manager.getSettings();
    if (s.closeOnLaunch && win) win.hide();
  });
  manager.on('game-exit', () => { if (win && !win.isVisible()) win.show(); });

  ipcMain.handle('call', async (_e, method, args) => {
    if (!API.includes(method)) throw new Error(`Unknown action ${method}`);
    try {
      return { ok: true, value: await manager[method](...(args || [])) };
    } catch (e) {
      return { ok: false, error: e.message || String(e) };
    }
  });

  ipcMain.handle('system', async (_e, what, arg) => {
    switch (what) {
      case 'info':
        return {
          version: PKG.version, totalMemMb: Math.floor(os.totalmem() / 1048576), dataRoot: DATA_ROOT,
          platform: process.platform, presets: Object.fromEntries(Object.entries(JVM_PRESETS).map(([k, v]) => [k, v.label])),
        };
      case 'openInstanceFolder': {
        const id = String(arg).replace(/[^a-z0-9-]/gi, '');
        return shell.openPath(manager.paths.gameDir(id));
      }
      case 'openDataFolder':
        return shell.openPath(DATA_ROOT);
      case 'openExternal':
        if (/^https:\/\//.test(arg)) await shell.openExternal(arg);
        return true;
      case 'importMrpack': {
        const r = await dialog.showOpenDialog(win, { title: 'Import a Modrinth modpack', filters: [{ name: 'Modrinth modpack', extensions: ['mrpack'] }], properties: ['openFile'] });
        if (r.canceled || !r.filePaths[0]) return { ok: true, value: null };
        try { return { ok: true, value: await manager.importMrpack(r.filePaths[0]) }; } catch (e) { return { ok: false, error: e.message }; }
      }
      case 'pickJava': {
        const r = await dialog.showOpenDialog(win, { title: 'Choose a Java executable', properties: ['openFile'] });
        return r.canceled ? null : r.filePaths[0];
      }
      case 'minimize': win.minimize(); return true;
      case 'maximize': if (win.isMaximized()) win.unmaximize(); else win.maximize(); return true;
      case 'close': win.close(); return true;
      default: throw new Error(`Unknown system action ${what}`);
    }
  });

  createWindow();
});

app.on('second-instance', () => {
  if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); }
});

app.on('window-all-closed', () => {
  // Games keep running after the launcher closes; they are separate processes.
  app.quit();
});
