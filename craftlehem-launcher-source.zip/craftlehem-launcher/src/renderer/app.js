'use strict';
/* global launcher */
// Craftlehem Launcher window. Talks to the launcher core through window.launcher.

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const LOADERS = { vanilla: 'Vanilla', fabric: 'Fabric', quilt: 'Quilt', neoforge: 'NeoForge', forge: 'Forge' };
const ICONS = {
  play: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 4.5v15l13-7.5z"/></svg>',
  stop: '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>',
  dots: '<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/></svg>',
  folder: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
  trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>',
  edit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 20h4L19 9l-4-4L4 16z"/></svg>',
  term: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9l3 3-3 3M13 15h4"/></svg>',
  plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M12 5v14M5 12h14"/></svg>',
  download: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3v12m0 0l-4-4m4 4l4-4M4 17v3h16v-3"/></svg>',
};

const state = {
  info: null, settings: null, accounts: { list: [], selected: null }, instances: [],
  progress: {}, page: 'home', current: null, tab: 'overview',
  discover: { type: 'modpack', query: '', sort: 'relevance', offset: 0, total: 0, target: null },
  server: null,
};

// ---------- small helpers ----------
async function api(method, ...args) {
  try { return await launcher.call(method, ...args); } catch (e) { toast(e.message, 'err'); throw e; }
}

function toast(msg, kind = '') {
  const t = document.createElement('div');
  t.className = `toast ${kind}`;
  t.textContent = msg;
  $('#toasts').appendChild(t);
  setTimeout(() => t.remove(), kind === 'err' ? 9000 : 4500);
}

function fmtTime(sec) {
  if (!sec) return 'Never played';
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
  return h ? `${h}h ${m}m played` : `${Math.max(1, m)}m played`;
}

function fmtNum(n) {
  if (n >= 1e6) return `${(n / 1e6).toFixed(1)}M`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(1)}k`;
  return String(n);
}

function ago(ts) {
  if (!ts) return '';
  const d = (Date.now() - ts) / 1000;
  if (d < 60) return 'just now';
  if (d < 3600) return `${Math.floor(d / 60)}m ago`;
  if (d < 86400) return `${Math.floor(d / 3600)}h ago`;
  return `${Math.floor(d / 86400)}d ago`;
}

function headHtml(acc, big = false) {
  if (acc && acc.skin && /^https?:\/\//.test(acc.skin)) {
    return `<div class="head${big ? ' big' : ''}" style="background-image:url('${esc(acc.skin)}')"></div>`;
  }
  return `<div class="head letter${big ? ' big' : ''}">${esc(((acc && acc.name) || '?')[0].toUpperCase())}</div>`;
}

function tileHtml(inst) {
  const letter = esc((inst.name || '?').trim()[0] || '?').toUpperCase();
  return inst.icon && /^https:\/\//.test(inst.icon) ? `<img src="${esc(inst.icon)}" alt="">` : letter;
}

function loaderLabel(inst) {
  const l = inst.loader || {};
  return LOADERS[l.type] || 'Vanilla';
}

// ---------- modal & menus ----------
function openModal(html, onMount) {
  $('#modal').innerHTML = html;
  $('#modalBack').classList.add('on');
  if (onMount) onMount($('#modal'));
}
function closeModal() { $('#modalBack').classList.remove('on'); $('#modal').innerHTML = ''; }
$('#modalBack').addEventListener('mousedown', (e) => { if (e.target.id === 'modalBack' && !$('#modal').dataset.locked) closeModal(); });

function confirmBox(title, text, okLabel = 'Confirm', danger = false) {
  return new Promise((resolve) => {
    openModal(`<h1>${esc(title)}</h1><p class="sub">${esc(text)}</p>
      <div class="actions"><button class="btn ghost" data-r="0">Cancel</button><button class="btn ${danger ? 'danger' : 'primary'}" data-r="1">${esc(okLabel)}</button></div>`, (m) => {
      $$('[data-r]', m).forEach((b) => b.addEventListener('click', () => { closeModal(); resolve(b.dataset.r === '1'); }));
    });
  });
}

let openMenuEl = null;
function showMenu(x, y, items) {
  closeMenu();
  const m = document.createElement('div');
  m.className = 'menu';
  m.innerHTML = items.map((it, i) => `<button data-i="${i}" class="${it.danger ? 'danger' : ''}">${it.icon || ''}${esc(it.label)}</button>`).join('');
  document.body.appendChild(m);
  const r = m.getBoundingClientRect();
  m.style.left = `${Math.min(x, innerWidth - r.width - 8)}px`;
  m.style.top = `${Math.min(y, innerHeight - r.height - 8)}px`;
  $$('button', m).forEach((b) => b.addEventListener('click', () => { closeMenu(); items[b.dataset.i].run(); }));
  openMenuEl = m;
}
function closeMenu() { if (openMenuEl) { openMenuEl.remove(); openMenuEl = null; } }
document.addEventListener('mousedown', (e) => { if (openMenuEl && !openMenuEl.contains(e.target)) closeMenu(); });

// ---------- navigation ----------
function go(page) {
  state.page = page;
  $$('.page').forEach((p) => p.classList.toggle('active', p.id === `page-${page}`));
  $$('#nav button').forEach((b) => b.classList.toggle('active', b.dataset.page === page || (page === 'instance' && b.dataset.page === 'library')));
  $('#main').scrollTop = 0;
  if (page === 'home') renderHome();
  if (page === 'library') renderLibrary();
  if (page === 'discover') { renderDiscoverChrome(); if (!$('#dResults').children.length) searchDiscover(true); }
  if (page === 'accounts') renderAccounts();
  if (page === 'settings') renderSettings();
}
$$('#nav button').forEach((b) => b.addEventListener('click', () => { state.discover.target = null; go(b.dataset.page); }));
$$('[data-goto]').forEach((b) => b.addEventListener('click', () => go(b.dataset.goto)));

$('#winMin').onclick = () => launcher.system('minimize');
$('#winMax').onclick = () => launcher.system('maximize');
$('#winClose').onclick = () => launcher.system('close');

// ---------- data loading ----------
async function loadInstances() {
  state.instances = await api('listInstances');
  renderAccountChip();
  if (state.page === 'home') renderHome(false);
  if (state.page === 'library') renderLibrary();
  if (state.page === 'instance' && state.current) {
    const inst = state.instances.find((i) => i.id === state.current);
    if (inst) renderInstanceHead(inst); else go('library');
  }
}

async function loadAccounts() {
  state.accounts = await api('listAccounts');
  renderAccountChip();
}

function currentAccount() {
  const a = state.accounts;
  return a.list.find((x) => x.uuid === a.selected) || a.list[0] || null;
}

function renderAccountChip() {
  const acc = currentAccount();
  $('#accountChip').innerHTML = acc
    ? `${headHtml(acc)}<div class="who"><b>${esc(acc.name)}</b><small>${acc.type === 'msa' ? 'Microsoft account' : 'Offline'}</small></div>`
    : `<div class="head letter">+</div><div class="who"><b>Sign in</b><small>Add an account to play</small></div>`;
}
$('#accountChip').onclick = () => go('accounts');

// ---------- instance cards ----------
function cardHtml(inst) {
  const p = state.progress[inst.id];
  const busy = inst.busy || inst.installing;
  let foot;
  if (busy && p && p.label) {
    const pct = p.total ? Math.round((p.done / p.total) * 100) : 0;
    foot = `<div><div class="plabel">${esc(p.label)}${p.total > 1 ? ` · ${pct}%` : ''}</div><div class="pbar" style="margin-top:6px"><i style="width:${p.total > 1 ? pct : 100}%"></i></div></div>`;
  } else if (inst.installError) {
    foot = `<div class="foot"><span class="tag red">Install failed</span><span class="stat"></span><button class="btn small icon ghost" data-menu="${esc(inst.id)}">${ICONS.dots}</button></div>`;
  } else {
    foot = `<div class="foot"><span class="stat">${esc(fmtTime(inst.playTime))}${inst.lastPlayed ? ` · ${esc(ago(inst.lastPlayed))}` : ''}</span>
      <button class="btn small icon ghost" data-menu="${esc(inst.id)}" title="More">${ICONS.dots}</button>
      ${inst.running
        ? `<button class="btn small running" data-stop="${esc(inst.id)}">${ICONS.stop}Stop</button>`
        : `<button class="btn small primary" data-play="${esc(inst.id)}" ${busy ? 'disabled' : ''}>${busy ? '<span class="spinner"></span>' : ICONS.play}Play</button>`}
    </div>`;
  }
  return `<div class="card" data-open="${esc(inst.id)}">
    <div class="top"><div class="tile">${tileHtml(inst)}</div>
      <div style="min-width:0"><div class="name">${esc(inst.name)}</div>
      <div class="meta"><span class="tag">${esc(inst.mc || '…')}</span><span class="tag accent">${esc(loaderLabel(inst))}</span>${inst.running ? '<span class="tag green">Running</span>' : ''}</div></div>
    </div>${foot}</div>`;
}

function wireCards(root) {
  $$('[data-play]', root).forEach((b) => b.addEventListener('click', (e) => { e.stopPropagation(); playInstance(b.dataset.play); }));
  $$('[data-stop]', root).forEach((b) => b.addEventListener('click', (e) => { e.stopPropagation(); api('kill', b.dataset.stop); }));
  $$('[data-menu]', root).forEach((b) => b.addEventListener('click', (e) => {
    e.stopPropagation();
    const r = b.getBoundingClientRect();
    instanceMenu(b.dataset.menu, r.left, r.bottom + 4);
  }));
  $$('[data-open]', root).forEach((c) => c.addEventListener('click', () => openInstance(c.dataset.open)));
  $$('[data-new]', root).forEach((c) => c.addEventListener('click', newInstanceModal));
}

function instanceMenu(id, x, y) {
  showMenu(x, y, [
    { label: 'Open', icon: ICONS.edit, run: () => openInstance(id) },
    { label: 'Open folder', icon: ICONS.folder, run: () => launcher.system('openInstanceFolder', id) },
    { label: 'Console', icon: ICONS.term, run: () => openInstance(id, 'console') },
    { label: 'Delete', icon: ICONS.trash, danger: true, run: () => deleteInstance(id) },
  ]);
}

async function deleteInstance(id) {
  const inst = state.instances.find((i) => i.id === id);
  if (!(await confirmBox('Delete instance?', `"${inst ? inst.name : id}" and everything in it (worlds, mods, screenshots) will be removed for good.`, 'Delete', true))) return;
  await api('deleteInstance', id);
  toast('Instance deleted');
  if (state.current === id) go('library');
}

async function playInstance(id, opts) {
  if (!currentAccount()) { toast('Add an account first.', 'err'); go('accounts'); return; }
  try {
    await api('play', id, opts || {});
  } catch { /* toast already shown */ }
}

// ---------- home ----------
function gaugeSvg(online, max) {
  const frac = max ? Math.min(1, online / max) : 0;
  const R = 86, C = 2 * Math.PI * R, arc = C * 0.75;
  const ticks = Array.from({ length: 31 }, (_, i) => {
    const a = (135 + (270 * i) / 30) * (Math.PI / 180);
    const r1 = i % 5 === 0 ? 70 : 74, r2 = 78;
    return `<line x1="${105 + r1 * Math.cos(a)}" y1="${105 + r1 * Math.sin(a)}" x2="${105 + r2 * Math.cos(a)}" y2="${105 + r2 * Math.sin(a)}" stroke="${i / 30 <= frac && frac > 0 ? '#c49bff' : '#3a3352'}" stroke-width="${i % 5 === 0 ? 2.2 : 1.2}"/>`;
  }).join('');
  return `<svg viewBox="0 0 210 210"><defs><linearGradient id="gg" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#6a45a8"/><stop offset="1" stop-color="#c49bff"/></linearGradient></defs>
    <circle cx="105" cy="105" r="${R}" fill="none" stroke="#1b1825" stroke-width="10" stroke-dasharray="${arc} ${C}" transform="rotate(135 105 105)" stroke-linecap="round"/>
    <circle cx="105" cy="105" r="${R}" fill="none" stroke="url(#gg)" stroke-width="10" stroke-dasharray="${arc * frac} ${C}" transform="rotate(135 105 105)" stroke-linecap="round" style="filter:drop-shadow(0 0 6px rgba(166,108,255,.6))"/>
    ${ticks}</svg>`;
}

async function refreshServer() {
  const s = state.settings && state.settings.featuredServer;
  if (!s || !s.host) { $('#hero').style.display = 'none'; return; }
  $('#hero').style.display = '';
  try {
    state.server = await launcher.call('pingServer', s.host, Number(s.port) || 25565);
  } catch { state.server = { online: false }; }
  renderHero();
}

function renderHero() {
  const s = (state.settings && state.settings.featuredServer) || {};
  const st = state.server;
  $('#heroName').textContent = s.name || s.host;
  $('#heroAddr').textContent = `${s.host}${s.port && Number(s.port) !== 25565 ? `:${s.port}` : ''}`;
  $('#heroDot').className = `status-dot ${st ? (st.online ? 'on' : 'off') : ''}`;
  $('#heroMotd').textContent = st ? (st.online ? st.motd || 'Online' : 'Offline right now') : 'Checking server…';
  if (st && st.favicon && st.favicon.startsWith('data:image/')) $('#heroFavicon').src = st.favicon;
  const online = st && st.online && st.players ? st.players.online : 0;
  const max = st && st.online && st.players ? st.players.max : 0;
  $('#heroGauge').innerHTML = `${gaugeSvg(online, max)}<div class="readout"><b>${st && st.online ? online : '–'}</b>
    <span>${st && st.online ? `of ${max} online` : 'offline'}</span><small>${st && st.online ? `${st.latency} ms` : ''}</small></div>`;
  $('#heroAddr').textContent += st && st.online && st.version ? `  ·  ${st.version}` : '';

  const sel = $('#heroInstance');
  const prev = sel.value || (state.settings.featuredInstance || '');
  sel.innerHTML = state.instances.length
    ? state.instances.map((i) => `<option value="${esc(i.id)}">${esc(i.name)} (${esc(i.mc || '')})</option>`).join('')
    : '<option value="">Create an instance first</option>';
  if (prev && state.instances.some((i) => i.id === prev)) sel.value = prev;
}

$('#heroPlay').onclick = async () => {
  const id = $('#heroInstance').value;
  if (!id) { newInstanceModal(); return; }
  const s = state.settings.featuredServer;
  api('saveSettings', { featuredInstance: id }).then((x) => { state.settings = x; }).catch(() => {});
  playInstance(id, { server: { host: s.host, port: Number(s.port) || 25565 } });
};

function renderHome(ping = true) {
  renderHero();
  if (ping) refreshServer();
  const recent = state.instances.slice(0, 4);
  $('#recentCards').innerHTML = recent.map(cardHtml).join('')
    + (recent.length < 4 ? `<div class="card new" data-new="1">${ICONS.plus}New instance</div>` : '');
  wireCards($('#recentCards'));
}

// ---------- library ----------
function renderLibrary() {
  const el = $('#libraryCards');
  el.innerHTML = state.instances.map(cardHtml).join('') + `<div class="card new" data-new="1">${ICONS.plus}New instance</div>`;
  wireCards(el);
}

$('#newBtn').onclick = newInstanceModal;
$('#importBtn').onclick = async () => {
  const r = await launcher.system('importMrpack');
  if (r && !r.ok) toast(r.error, 'err');
  else if (r && r.value) toast(`Imported ${r.value.name}`, 'ok');
};

async function newInstanceModal() {
  let versions = [];
  let snapshots = false;
  let loader = 'vanilla';
  openModal(`<div class="eyebrow">Library</div><h1>New instance</h1>
    <label class="field"><span>Name</span><input class="input" id="niName" placeholder="My instance"></label>
    <label class="field"><span>Mod loader</span><div class="chips" id="niLoader">
      ${Object.entries(LOADERS).map(([k, v]) => `<button class="chip ${k === 'vanilla' ? 'on' : ''}" data-l="${k}">${v}</button>`).join('')}</div></label>
    <div class="grid2">
      <label class="field"><span>Minecraft version</span><select class="input" id="niMc"><option>Loading…</option></select></label>
      <label class="field"><span>Loader version</span><select class="input" id="niLv" disabled><option value="">—</option></select></label>
    </div>
    <label class="toggle"><input type="checkbox" id="niSnap"><i></i><div><b>Show snapshots</b></div></label>
    <div class="actions"><button class="btn ghost" id="niCancel">Cancel</button><button class="btn primary" id="niCreate">Create</button></div>`, async (m) => {
    const mcSel = $('#niMc', m), lvSel = $('#niLv', m);
    async function fillMc() {
      versions = await api('minecraftVersions', snapshots);
      mcSel.innerHTML = versions.map((v) => `<option value="${esc(v.id)}">${esc(v.id)}${v.type !== 'release' ? ` (${esc(v.type)})` : ''}</option>`).join('');
      fillLoader();
    }
    async function fillLoader() {
      if (loader === 'vanilla') { lvSel.innerHTML = '<option value="">—</option>'; lvSel.disabled = true; return; }
      lvSel.disabled = true;
      lvSel.innerHTML = '<option>Loading…</option>';
      try {
        const list = await launcher.call('loaderVersions', loader, mcSel.value);
        if (!list.length) { lvSel.innerHTML = `<option value="">No ${LOADERS[loader]} for ${esc(mcSel.value)}</option>`; return; }
        const rec = list.find((v) => v.stable) || list[0];
        lvSel.innerHTML = list.slice(0, 80).map((v) => `<option value="${esc(v.version)}" ${v === rec ? 'selected' : ''}>${esc(v.version)}${v === rec ? ' (recommended)' : v.stable ? '' : ' (beta)'}</option>`).join('');
        lvSel.disabled = false;
      } catch (e) { lvSel.innerHTML = '<option value="">Could not load versions</option>'; }
    }
    $$('#niLoader .chip', m).forEach((c) => c.addEventListener('click', () => {
      loader = c.dataset.l;
      $$('#niLoader .chip', m).forEach((x) => x.classList.toggle('on', x === c));
      fillLoader();
    }));
    mcSel.addEventListener('change', fillLoader);
    $('#niSnap', m).addEventListener('change', (e) => { snapshots = e.target.checked; fillMc(); });
    $('#niCancel', m).onclick = closeModal;
    $('#niCreate', m).onclick = async () => {
      if (loader !== 'vanilla' && !lvSel.value) { toast(`Pick a ${LOADERS[loader]} version.`, 'err'); return; }
      const inst = await api('createInstance', {
        name: $('#niName', m).value.trim() || `${LOADERS[loader]} ${mcSel.value}`,
        mc: mcSel.value, loader: { type: loader, version: loader === 'vanilla' ? null : lvSel.value },
      });
      closeModal();
      toast(`Created ${inst.name}`, 'ok');
      await loadInstances();
      openInstance(inst.id);
    };
    fillMc().catch(() => {});
  });
}

// ---------- instance detail ----------
async function openInstance(id, tab = 'overview') {
  state.current = id;
  state.tab = tab;
  go('instance');
  const inst = state.instances.find((i) => i.id === id) || (await api('getInstance', id));
  renderInstanceHead(inst);
  showTab(tab);
}

function renderInstanceHead(inst) {
  $('#dTile').innerHTML = tileHtml(inst);
  $('#dEyebrow').textContent = inst.source && inst.source.type === 'modrinth' ? 'Modrinth modpack' : 'Instance';
  $('#dName').textContent = inst.name;
  $('#dTags').innerHTML = `<span class="tag">Minecraft ${esc(inst.mc || '…')}</span><span class="tag accent">${esc(loaderLabel(inst))} ${esc((inst.loader && inst.loader.version) || '')}</span>
    <span class="tag">${esc(fmtTime(inst.playTime))}</span>${inst.running ? '<span class="tag green">Running</span>' : ''}`;
  const b = $('#dPlay');
  const p = state.progress[inst.id];
  if (inst.running) { b.className = 'btn play running'; b.innerHTML = `${ICONS.stop}Stop`; b.disabled = false; b.onclick = () => api('kill', inst.id); }
  else if (inst.busy || inst.installing) { b.className = 'btn primary play'; b.innerHTML = `<span class="spinner"></span>${esc((p && p.label) || 'Working')}`; b.disabled = true; }
  else { b.className = 'btn primary play'; b.innerHTML = `${ICONS.play}Play`; b.disabled = false; b.onclick = () => playInstance(inst.id); }
  $('#dFolder').onclick = () => launcher.system('openInstanceFolder', inst.id);
}

$('#backBtn').onclick = () => go('library');
$$('#dTabs button').forEach((b) => b.addEventListener('click', () => showTab(b.dataset.tab)));

function showTab(tab) {
  state.tab = tab;
  $$('#dTabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
  $$('.tabpane').forEach((p) => p.classList.toggle('on', p.id === `tab-${tab}`));
  if (tab === 'overview') renderOverview();
  if (tab === 'mods') renderMods();
  if (tab === 'console') renderConsole();
}

async function renderOverview() {
  const inst = await api('getInstance', state.current);
  const s = state.settings;
  const total = state.info.totalMemMb;
  const mem = inst.memory || null;
  const presets = state.info.presets;
  $('#tab-overview').innerHTML = `<div class="settings-grid">
    <div class="panel rivets"><h2>Game</h2>
      <label class="field"><span>Name</span><input class="input" id="oName" value="${esc(inst.name)}"></label>
      <label class="field"><span>Auto-join server</span><input class="input" id="oServer" placeholder="Leave empty to open the main menu" value="${esc(inst.server ? `${inst.server.host}${inst.server.port && inst.server.port !== 25565 ? `:${inst.server.port}` : ''}` : '')}">
        <small>Minecraft connects straight to this server when you press Play.</small></label>
      <div class="row"><button class="btn primary" id="oSave">Save</button><span class="grow"></span><button class="btn danger" id="oDelete">${ICONS.trash}Delete</button></div>
    </div>
    <div class="panel rivets"><h2>Performance</h2>
      <label class="toggle"><input type="checkbox" id="oMemCustom" ${mem ? 'checked' : ''}><i></i><div><b>Custom memory for this instance</b><small>Otherwise uses the launcher default (${(s.memoryMax / 1024).toFixed(1)} GB)</small></div></label>
      <label class="field" id="oMemWrap" style="${mem ? '' : 'opacity:.4;pointer-events:none'}"><span>Maximum memory · <b class="mem-readout" id="oMemVal"></b></span>
        <input type="range" id="oMem" min="1024" max="${Math.max(2048, total - 1024)}" step="512" value="${mem ? mem.max : s.memoryMax}"></label>
      <label class="field"><span>Java garbage collector</span><select class="input" id="oPreset"><option value="">Launcher default</option>
        ${Object.entries(presets).map(([k, v]) => `<option value="${k}" ${inst.preset === k ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select></label>
      <label class="field"><span>Extra Java arguments</span><input class="input" id="oArgs" value="${esc(inst.extraJvmArgs || '')}" placeholder="-Dsome.flag=true"></label>
    </div></div>`;
  const memVal = () => { $('#oMemVal').textContent = `${(Number($('#oMem').value) / 1024).toFixed(1)} GB`; };
  memVal();
  $('#oMem').addEventListener('input', memVal);
  $('#oMemCustom').addEventListener('change', (e) => { $('#oMemWrap').style.cssText = e.target.checked ? '' : 'opacity:.4;pointer-events:none'; });
  $('#oDelete').onclick = () => deleteInstance(inst.id);
  $('#oSave').onclick = async () => {
    const srv = $('#oServer').value.trim();
    let server = null;
    if (srv) { const [host, port] = srv.split(':'); server = { host, port: Number(port) || 25565 }; }
    const max = Number($('#oMem').value);
    await api('updateInstance', inst.id, {
      name: $('#oName').value.trim() || inst.name,
      server,
      memory: $('#oMemCustom').checked ? { min: Math.min(2048, max), max } : null,
      preset: $('#oPreset').value || null,
      extraJvmArgs: $('#oArgs').value.trim(),
    });
    toast('Saved', 'ok');
    loadInstances();
  };
}

async function renderMods() {
  const inst = state.instances.find((i) => i.id === state.current);
  const mods = await api('listMods', state.current);
  const vanilla = inst && inst.loader.type === 'vanilla';
  $('#tab-mods').innerHTML = `<div class="row" style="margin-bottom:14px">
      <div class="search grow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg><input class="input" id="mFilter" placeholder="Filter ${mods.length} mods"></div>
      <button class="btn primary" id="mAdd" ${vanilla ? 'disabled title="Vanilla instances cannot load mods"' : ''}>${ICONS.plus}Add mods</button></div>
    ${mods.length ? `<div class="list" id="mList">${mods.map((m) => `<div class="item ${m.enabled ? '' : 'off'}" data-f="${esc(m.file.toLowerCase())}">
      <label class="toggle" style="margin:0"><input type="checkbox" data-toggle="${esc(m.file)}" ${m.enabled ? 'checked' : ''}><i></i></label>
      <span class="fname">${esc(m.file.replace(/\.disabled$/, ''))}</span><small>${(m.size / 1048576).toFixed(1)} MB</small></div>`).join('')}</div>`
      : `<div class="empty"><b>No mods yet</b>${vanilla ? 'This is a vanilla instance.' : 'Add some from Modrinth.'}</div>`}`;
  $$('[data-toggle]').forEach((t) => t.addEventListener('change', async () => { await api('toggleMod', state.current, t.dataset.toggle); renderMods(); }));
  const f = $('#mFilter');
  if (f) f.addEventListener('input', () => $$('#mList .item').forEach((it) => { it.style.display = it.dataset.f.includes(f.value.toLowerCase()) ? '' : 'none'; }));
  $('#mAdd').onclick = () => { state.discover.target = state.current; state.discover.type = 'mod'; $('#dResults').innerHTML = ''; go('discover'); };
}

function logLineHtml(l) {
  return `<div class="l ${esc(l.level)}">${l.time ? `<span class="t">${esc(l.time)}</span>` : ''}${l.thread ? `<span class="t">[${esc(l.thread)}/${esc(l.level)}]</span>` : ''}${esc(l.text)}</div>`;
}

async function renderConsole() {
  const lines = await api('getLog', state.current);
  const c = $('#console');
  c.innerHTML = lines.length ? lines.slice(-3000).map(logLineHtml).join('') : '<div class="l LAUNCHER">The game log appears here when you press Play.</div>';
  c.scrollTop = c.scrollHeight;
}

function appendConsole(lines) {
  const c = $('#console');
  const stick = c.scrollTop + c.clientHeight >= c.scrollHeight - 40;
  if (c.children.length === 1 && c.firstChild.textContent.startsWith('The game log')) c.innerHTML = '';
  c.insertAdjacentHTML('beforeend', lines.map(logLineHtml).join(''));
  while (c.children.length > 4000) c.firstChild.remove();
  if (stick) c.scrollTop = c.scrollHeight;
}

// ---------- discover ----------
function renderDiscoverChrome() {
  const d = state.discover;
  $$('#dType .chip').forEach((c) => c.classList.toggle('on', c.dataset.type === d.type));
  const t = d.target && state.instances.find((i) => i.id === d.target);
  $('#page-discover .eyebrow').textContent = t ? `Adding to ${t.name} · ${t.mc} ${loaderLabel(t)}` : 'Powered by Modrinth';
}

let searchTimer = null;
async function searchDiscover(reset) {
  const d = state.discover;
  if (reset) { d.offset = 0; $('#dResults').innerHTML = '<div class="empty"><span class="spinner"></span></div>'; }
  const t = d.target && state.instances.find((i) => i.id === d.target);
  try {
    const r = await launcher.call('searchModrinth', {
      query: d.query, type: d.type, sort: d.sort, offset: d.offset, limit: 24,
      mc: t ? t.mc : undefined, loader: t && d.type === 'mod' ? t.loader.type : undefined,
    });
    if (reset) $('#dResults').innerHTML = '';
    d.total = r.total;
    d.offset += r.hits.length;
    $('#dResults').insertAdjacentHTML('beforeend', r.hits.map(resultHtml).join('') || (reset ? '<div class="empty"><b>Nothing found</b>Try a different search.</div>' : ''));
    $$('#dResults [data-act]:not([data-wired])').forEach((b) => { b.dataset.wired = 1; b.addEventListener('click', () => resultAction(b)); });
    $('#dMore').style.display = d.offset < d.total ? '' : 'none';
  } catch (e) {
    $('#dResults').innerHTML = `<div class="empty"><b>Could not reach Modrinth</b>${esc(e.message)}</div>`;
  }
}

function resultHtml(h) {
  const isPack = h.type === 'modpack';
  return `<div class="result">
    ${h.icon ? `<img class="ic" src="${esc(h.icon)}" alt="" loading="lazy">` : '<div class="ic"></div>'}
    <div class="body"><div class="t">${esc(h.title)}</div><div class="by">by ${esc(h.author)}</div><div class="d">${esc(h.description)}</div>
      <div class="foot"><span class="n">${ICONS.download.replace('<svg', '<svg style="width:12px;height:12px;vertical-align:-1px"')} ${fmtNum(h.downloads)}</span>
        <button class="btn small ghost" data-act="page" data-slug="${esc(h.slug)}" data-type="${esc(h.type)}">Page</button>
        <button class="btn small primary" data-act="${isPack ? 'install' : 'add'}" data-id="${esc(h.id)}" data-title="${esc(h.title)}" data-icon="${esc(h.icon || '')}" data-type="${esc(h.type)}">${isPack ? 'Install' : 'Add'}</button></div></div></div>`;
}

async function resultAction(b) {
  if (b.dataset.act === 'page') { launcher.system('openExternal', `https://modrinth.com/${b.dataset.type}/${b.dataset.slug}`); return; }
  if (b.dataset.act === 'install') {
    toast(`Installing ${b.dataset.title}… you can keep browsing.`);
    go('library');
    try {
      const inst = await launcher.call('installModrinthPack', b.dataset.id, null, b.dataset.title);
      if (b.dataset.icon) await launcher.call('updateInstance', inst.id, { icon: b.dataset.icon });
      toast(`${b.dataset.title} is ready to play`, 'ok');
      loadInstances();
    } catch (e) { toast(`Install failed: ${e.message}`, 'err'); loadInstances(); }
    return;
  }
  // Add a mod/shader/resource pack to an instance.
  const type = b.dataset.type;
  const target = state.discover.target;
  const add = async (id) => {
    try {
      const files = await launcher.call('addModToInstance', id, b.dataset.id, type);
      toast(`Added ${files.length > 1 ? `${files[0]} + ${files.length - 1} required` : files[0]}`, 'ok');
    } catch (e) { toast(e.message, 'err'); }
  };
  if (target) { add(target); return; }
  const usable = state.instances.filter((i) => type !== 'mod' || i.loader.type !== 'vanilla');
  if (!usable.length) { toast('Create an instance with a mod loader first.', 'err'); return; }
  openModal(`<h1>Add ${esc(b.dataset.title)} to…</h1><div class="list">${usable.map((i) => `<div class="item"><span class="fname" style="font-family:var(--body)">${esc(i.name)}</span>
    <span class="tag">${esc(i.mc)}</span><span class="tag accent">${esc(loaderLabel(i))}</span><button class="btn small primary" data-pick="${esc(i.id)}">Add</button></div>`).join('')}</div>
    <div class="actions"><button class="btn ghost" id="pkCancel">Cancel</button></div>`, (m) => {
    $('#pkCancel', m).onclick = closeModal;
    $$('[data-pick]', m).forEach((p) => p.addEventListener('click', () => { closeModal(); add(p.dataset.pick); }));
  });
}

$$('#dType .chip').forEach((c) => c.addEventListener('click', () => { state.discover.type = c.dataset.type; renderDiscoverChrome(); searchDiscover(true); }));
$('#dQuery').addEventListener('input', (e) => { state.discover.query = e.target.value; clearTimeout(searchTimer); searchTimer = setTimeout(() => searchDiscover(true), 300); });
$('#dSort').addEventListener('change', (e) => { state.discover.sort = e.target.value; searchDiscover(true); });
$('#dMore').onclick = () => searchDiscover(false);

// ---------- accounts ----------
async function renderAccounts() {
  await loadAccounts();
  const a = state.accounts;
  const hasMs = a.list.some((x) => x.type === 'msa');
  $('#addOffline').style.display = hasMs ? '' : 'none';
  const noId = !state.settings.clientId;
  $('#accountList').innerHTML = (noId ? `<div class="note warn"><b>Microsoft sign-in isn't set up yet.</b> This build needs its Azure app ID before it can log in. Add it in Settings → Microsoft sign-in.</div>` : '')
    + (a.list.length ? a.list.map((x) => `<div class="acct ${x.uuid === a.selected ? 'sel' : ''}">
      ${headHtml(x, true)}<div class="who"><b>${esc(x.name)}</b><small>${x.type === 'msa' ? 'Microsoft account' : 'Offline (singleplayer & offline servers)'} · ${esc(x.uuid)}</small></div>
      ${x.uuid === a.selected ? '<span class="tag accent">Selected</span>' : `<button class="btn small" data-sel="${esc(x.uuid)}">Use</button>`}
      <button class="btn small ghost icon" data-rm="${esc(x.uuid)}" title="Remove">${ICONS.trash}</button></div>`).join('')
      : '<div class="empty"><b>No accounts yet</b>Sign in with the Microsoft account that owns Minecraft: Java Edition.</div>');
  $$('[data-sel]').forEach((b) => b.addEventListener('click', async () => { await api('selectAccount', b.dataset.sel); renderAccounts(); }));
  $$('[data-rm]').forEach((b) => b.addEventListener('click', async () => {
    if (!(await confirmBox('Remove account?', 'You can sign in again any time.', 'Remove', true))) return;
    await api('removeAccount', b.dataset.rm); renderAccounts();
  }));
}

$('#addMs').onclick = () => {
  openModal(`<div class="eyebrow">Microsoft</div><h1>Sign in</h1><div class="code-box" id="lgBody"><span class="spinner"></span><p class="sub">Asking Microsoft for a sign-in code…</p></div>
    <div class="actions"><button class="btn ghost" id="lgCancel">Cancel</button></div>`, (m) => {
    m.dataset.locked = '1';
    $('#lgCancel', m).onclick = () => { launcher.call('cancelLogin').catch(() => {}); delete m.dataset.locked; closeModal(); };
  });
  launcher.call('loginMicrosoft').then((acc) => {
    delete $('#modal').dataset.locked;
    closeModal();
    toast(`Signed in as ${acc.name}`, 'ok');
    renderAccounts();
  }).catch((e) => {
    const body = $('#lgBody');
    if (body && !/cancelled/i.test(e.message)) body.innerHTML = `<p class="sub" style="color:var(--red)">${esc(e.message)}</p>`;
    delete $('#modal').dataset.locked;
  });
};

launcher.on('login-code', ({ userCode, url }) => {
  const body = $('#lgBody');
  if (!body) return;
  body.innerHTML = `<p class="sub">Open <b>${esc(url)}</b> and enter this code:</p><div class="code">${esc(userCode)}</div>
    <div class="row" style="justify-content:center"><button class="btn" id="lgCopy">Copy code</button><button class="btn primary" id="lgOpen">Open sign-in page</button></div>
    <p class="sub" style="margin-top:14px"><span class="spinner" style="vertical-align:-3px;margin-right:8px"></span>Waiting for you to approve…</p>`;
  $('#lgCopy').onclick = () => navigator.clipboard.writeText(userCode).then(() => toast('Code copied')).catch(() => toast('Select the code and press Ctrl+C'));
  $('#lgOpen').onclick = () => launcher.system('openExternal', url);
});

$('#addOffline').onclick = () => {
  openModal(`<h1>Offline name</h1><p class="sub">For singleplayer and offline-mode servers. Online servers still need your Microsoft account.</p>
    <label class="field" style="margin-top:14px"><span>Username</span><input class="input" id="ofName" maxlength="16"></label>
    <div class="actions"><button class="btn ghost" id="ofCancel">Cancel</button><button class="btn primary" id="ofAdd">Add</button></div>`, (m) => {
    $('#ofCancel', m).onclick = closeModal;
    $('#ofAdd', m).onclick = async () => { await api('addOfflineAccount', $('#ofName', m).value.trim()); closeModal(); renderAccounts(); };
  });
};

// ---------- settings ----------
function renderSettings() {
  const s = state.settings;
  const total = state.info.totalMemMb;
  const fs = s.featuredServer || {};
  $('#settingsForm').innerHTML = `
    <div class="panel rivets"><h2>Memory & Java</h2>
      <label class="field"><span>Maximum memory · <b class="mem-readout" id="sMemVal"></b></span>
        <input type="range" id="sMem" min="1024" max="${Math.max(2048, total - 1024)}" step="512" value="${s.memoryMax}">
        <small>Your PC has ${(total / 1024).toFixed(0)} GB. Big modpacks like ATM10 run best on 8–12 GB; more than that rarely helps.</small></label>
      <label class="field"><span>Java garbage collector</span><select class="input" id="sPreset">
        ${Object.entries(state.info.presets).map(([k, v]) => `<option value="${k}" ${s.preset === k ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select>
        <small>Tuned G1 is the safe all-rounder. Generational ZGC gives the smoothest frame times on Java 21+ packs if you have RAM to spare.</small></label>
      <label class="field"><span>Extra Java arguments (all instances)</span><input class="input" id="sArgs" value="${esc(s.extraJvmArgs || '')}"></label>
      <label class="field"><span>Java executable</span><div class="row"><input class="input" id="sJava" value="${esc(s.javaPath || '')}" placeholder="Automatic (downloads the right Java for each version)"><button class="btn" id="sJavaPick">Browse</button></div></label>
    </div>
    <div>
      <div class="panel rivets" style="margin-bottom:16px"><h2>Featured server</h2>
        <div class="grid2"><label class="field"><span>Name</span><input class="input" id="sSrvName" value="${esc(fs.name || '')}"></label>
        <label class="field"><span>Address</span><input class="input" id="sSrvHost" value="${esc(fs.host || '')}${fs.port && Number(fs.port) !== 25565 ? `:${esc(fs.port)}` : ''}" placeholder="play.example.net"></label></div>
        <small style="color:var(--faint)">Shown on the Home page with live player count. Leave the address empty to hide it.</small>
      </div>
      <div class="panel rivets" style="margin-bottom:16px"><h2>Launcher</h2>
        <label class="toggle"><input type="checkbox" id="sHide" ${s.closeOnLaunch ? 'checked' : ''}><i></i><div><b>Hide the launcher while playing</b><small>It comes back when the game closes.</small></div></label>
        <div class="row"><button class="btn" id="sData">${ICONS.folder}Open data folder</button><span class="grow"></span><small style="color:var(--faint)">v${esc(state.info.version)}</small></div>
      </div>
      <div class="panel rivets"><h2>Microsoft sign-in</h2>
        ${s.builtInClientId ? '<div class="note">This build has a Mojang-approved sign-in ID built in. You only need the field below if you build your own copy.</div>' : ''}
        <label class="field"><span>Azure application (client) ID${s.builtInClientId ? ' (advanced)' : ''}</span><input class="input" id="sClient" value="${esc(s.clientId || '')}" placeholder="00000000-0000-0000-0000-000000000000">
          <small>Every launcher needs its own ID, approved by Mojang. <a href="#" id="sClientHelp" style="color:var(--accent-hi)">How to get one</a></small></label>
      </div>
    </div>
    <div style="grid-column:1/-1" class="row"><span class="grow"></span><button class="btn primary" id="sSave">Save settings</button></div>`;
  const memVal = () => { $('#sMemVal').textContent = `${(Number($('#sMem').value) / 1024).toFixed(1)} GB`; };
  memVal();
  $('#sMem').addEventListener('input', memVal);
  $('#sJavaPick').onclick = async () => { const p = await launcher.system('pickJava'); if (p) $('#sJava').value = p; };
  $('#sData').onclick = () => launcher.system('openDataFolder');
  $('#sClientHelp').onclick = (e) => { e.preventDefault(); launcher.system('openExternal', 'https://aka.ms/mce-reviewappid'); };
  $('#sSave').onclick = async () => {
    const max = Number($('#sMem').value);
    const [host, port] = $('#sSrvHost').value.trim().split(':');
    state.settings = await api('saveSettings', {
      memoryMax: max, memoryMin: Math.min(2048, max), preset: $('#sPreset').value, extraJvmArgs: $('#sArgs').value.trim(),
      javaPath: $('#sJava').value.trim(), closeOnLaunch: $('#sHide').checked, clientId: $('#sClient').value.trim(),
      featuredServer: { name: $('#sSrvName').value.trim(), host: host || '', port: Number(port) || 25565 },
    });
    toast('Settings saved', 'ok');
  };
}

// ---------- live events ----------
let progressPaint = null;
launcher.on('progress', (p) => {
  if (p.finished) delete state.progress[p.id]; else state.progress[p.id] = p;
  // Title-bar task indicator shows the most recent job.
  const active = Object.values(state.progress).filter((x) => x.label);
  const task = $('#task');
  if (active.length) {
    const a = active[active.length - 1];
    const inst = state.instances.find((i) => i.id === a.id);
    task.classList.add('on');
    $('#taskLabel').textContent = `${inst ? `${inst.name}: ` : ''}${a.label}`;
    $('#taskBar').style.width = `${a.total ? Math.round((a.done / a.total) * 100) : 100}%`;
  } else task.classList.remove('on');
  // Repaint cards at most ~6 times a second.
  if (!progressPaint) progressPaint = setTimeout(() => {
    progressPaint = null;
    if (state.page === 'library') renderLibrary();
    if (state.page === 'home') { $('#recentCards').innerHTML = state.instances.slice(0, 4).map(cardHtml).join('') + (state.instances.length < 4 ? `<div class="card new" data-new="1">${ICONS.plus}New instance</div>` : ''); wireCards($('#recentCards')); }
    if (state.page === 'instance') { const inst = state.instances.find((i) => i.id === state.current); if (inst) renderInstanceHead(inst); }
  }, 160);
});

launcher.on('log', ({ id, lines }) => {
  if (state.page === 'instance' && state.current === id && state.tab === 'console') appendConsole(lines);
});
launcher.on('instances-changed', () => loadInstances());
launcher.on('game-started', ({ id }) => {
  const inst = state.instances.find((i) => i.id === id);
  toast(`${inst ? inst.name : 'Minecraft'} is starting…`, 'ok');
});
launcher.on('game-exit', ({ id, code }) => {
  if (code && code !== 0 && code !== 143) {
    const inst = state.instances.find((i) => i.id === id);
    toast(`${inst ? inst.name : 'The game'} closed with an error (code ${code}). Check its Console tab.`, 'err');
  }
});

// ---------- start ----------
(async function init() {
  state.info = await launcher.system('info');
  $('#appVer').textContent = `CRAFTLEHEM · V${state.info.version}`;
  state.settings = await api('getSettings');
  await loadAccounts();
  await loadInstances();
  go('home');
  setInterval(() => { if (state.page === 'home') refreshServer(); }, 30000);
})();
