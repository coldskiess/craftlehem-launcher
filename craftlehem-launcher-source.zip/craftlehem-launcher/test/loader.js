const {Paths}=require('../src/core/paths');const L=require('../src/core/launch');const Ld=require('../src/core/loaders');
const paths=new Paths('/home/claude/cl-data');
(async()=>{const [type,mc]=process.argv.slice(2);
 const vs=await Ld.listVersions(type,mc); console.log(type,mc,'versions:',vs.length,'latest',vs[0]);
 if(type==='neoforge'||type==='forge'){console.log('(installer types not executed in this test)');return}
 const id=await Ld.install(paths,{type,mc}); console.log('installed',id);
 const r=await L.prepare(paths,id,{}); console.log('prepared',r.version.id,'main',r.version.mainClass,'cp',r.libs.classpath.length,'jar',r.client.jarFile);
})().catch(e=>{console.error('FAIL',e);process.exit(1)});
