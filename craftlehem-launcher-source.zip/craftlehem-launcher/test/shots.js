// Dev harness: start the real launcher, click through pages and save screenshots.
const { app } = require('electron');
const fs = require('fs');
const out = process.env.SHOTS_DIR || '/tmp/shots';
fs.mkdirSync(out, { recursive: true });
app.on('browser-window-created', (_e, win) => {
  win.webContents.on('console-message', (_ev, level, msg) => { if (level >= 2) console.log('[renderer]', msg); });
  win.webContents.once('did-finish-load', async () => {
    const wait = (ms) => new Promise((r) => setTimeout(r, ms));
    const js = (code) => win.webContents.executeJavaScript(code);
    const shot = async (name) => { const img = await win.webContents.capturePage(); fs.writeFileSync(`${out}/${name}.png`, img.toPNG()); console.log('shot', name); };
    await wait(3500); await shot('1-home');
    await js("document.querySelector('[data-page=library]').click()"); await wait(800); await shot('2-library');
    await js("document.querySelector('[data-open]').click()"); await wait(1200); await shot('3-instance');
    await js("document.querySelector('[data-tab=mods]').click()"); await wait(800); await shot('4-mods');
    await js("document.querySelector('[data-page=discover]').click()"); await wait(4000); await shot('5-discover');
    await js("document.querySelector('[data-page=accounts]').click()"); await wait(800); await shot('6-accounts');
    await js("document.querySelector('[data-page=settings]').click()"); await wait(800); await shot('7-settings');
    await js("document.querySelector('[data-page=library]').click()"); await wait(300); await js("document.querySelector('#newBtn').click()"); await wait(2500); await shot('8-new');
    app.quit();
  });
});
require('../src/main/main.js');
