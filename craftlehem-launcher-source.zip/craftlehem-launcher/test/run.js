const {Paths}=require('../src/core/paths');const L=require('../src/core/launch');
const paths=new Paths('/home/claude/cl-data');
const id=process.argv[2]; const secs=Number(process.argv[3]||90);
let log='';
(async()=>{
 const child=await L.launch(paths,{versionId:id,gameDir:'/home/claude/cl-data/instances/test-'+id.replace(/[^a-z0-9.-]/gi,'_')+'/minecraft',
  account:{name:'coldskiess_test',type:'offline'},memory:{min:512,max:3072},preset:process.argv[4]||'optimized',
  onLog:s=>{log+=s;process.stdout.write(s.replace(/Command: .*/,'Command: <hidden>'))},onExit:c=>{console.log('\n### EXIT',c);process.exit(0)}});
 setTimeout(()=>{console.log('\n### still running after',secs,'s -> killing');child.kill('SIGKILL');setTimeout(()=>process.exit(0),1000)},secs*1000);
})().catch(e=>{console.error('FAIL',e);process.exit(1)});
