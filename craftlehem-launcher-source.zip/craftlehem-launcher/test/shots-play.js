const { app } = require('electron'); const fs = require('fs');
app.on('browser-window-created', (_e, win) => {
  win.webContents.once('did-finish-load', async () => {
    const wait = (ms) => new Promise((r) => setTimeout(r, ms));
    const js = (c) => win.webContents.executeJavaScript(c);
    const shot = async (n) => fs.writeFileSync(`/tmp/shots/${n}.png`, (await win.webContents.capturePage()).toPNG());
    await wait(2500);
    await js("document.querySelector('[data-page=library]').click()"); await wait(500);
    await js("document.querySelector('[data-play]').click()"); await wait(2500); await shot('9-launching');
    await js("document.querySelector('[data-open]').click()"); await wait(600);
    await js("document.querySelector('[data-tab=console]').click()"); await wait(45000); await shot('10-console');
    const running = await js("document.querySelector('#dPlay').textContent");
    console.log('play button now:', running);
    await js("document.querySelector('#dPlay').click()"); await wait(3000); await shot('11-stopped');
    app.quit();
  });
});
require('../src/main/main.js');
