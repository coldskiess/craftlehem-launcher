const {Paths}=require('../src/core/paths');const L=require('../src/core/launch');
const paths=new Paths('/home/claude/cl-data');
let last=0;
const onProgress=p=>{const now=Date.now(); if(now-last>3000||p.done===p.total){last=now;console.log(p.label,p.done,'/',p.total)}};
(async()=>{const id=process.argv[2]||'1.21.1';
const t=Date.now(); const r=await L.prepare(paths,id,{onProgress});
console.log('OK java',r.javaBin,'libs',r.libs.classpath.length,'natives',r.libs.nativeJars.length,'assets',r.assets.jobs.length,'secs',(Date.now()-t)/1000);
})().catch(e=>{console.error('FAIL',e);process.exit(1)});
