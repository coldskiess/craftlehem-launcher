const {Manager}=require('../src/core/manager');
const m=new Manager('/home/claude/cl-data');
let last=0; m.on('progress',p=>{const n=Date.now(); if(p.label&&(n-last>4000||p.done===p.total)){last=n;console.log(' ',p.label,p.done,'/',p.total)}});
(async()=>{
 const r=await m.searchModrinth({query:'fabulously optimized',type:'modpack'}); console.log('search hits',r.total, r.hits.slice(0,3).map(h=>h.title+' '+h.id));
 const fo=r.hits.find(h=>/fabulously/i.test(h.title));
 // pick a version for 1.21.1 so it matches cached files
 const vs=await require('../src/core/modrinth').versions(fo.id,{mc:'1.21.1'}); console.log('FO 1.21.1 versions',vs.length, vs[0]&&vs[0].version_number);
 const inst=await m.installModrinthPack(fo.id, vs[0].id, fo.title);
 console.log('installed', inst.id, inst.mc, inst.loader, inst.versionId);
 console.log('mods', (await m.listMods(inst.id)).length);
})().catch(e=>{console.error('FAIL',e);process.exit(1)});
