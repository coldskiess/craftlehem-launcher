const {Manager}=require('../src/core/manager');
const m=new Manager('/home/claude/cl-data'); const id=process.argv[2]; const secs=+process.argv[3]||120;
m.on('log',({text})=>{for(const l of text.split('\n')) if(/CDATA\[(Loading|Fabric|Setting user|Created: 1024|Sodium|.*mods)|ERROR|Craftlehem\] (Java|Launching)/.test(l)) console.log(l.trim().slice(0,200))});
m.on('game-exit',e=>{console.log('### exit',e.code);process.exit(0)});
m.saveSettings({memoryMax:3072,memoryMin:512}).then(()=>m.play(id)).then(()=>setTimeout(()=>{console.log('### still running after',secs,'s');
  const {execSync}=require('child_process'); try{execSync('import -window root /tmp/shot-'+id+'.png')}catch(e){console.log('no screenshot',e.message.slice(0,80))}
  m.kill(id)},secs*1000)).catch(e=>{console.error('FAIL',e);process.exit(1)});
