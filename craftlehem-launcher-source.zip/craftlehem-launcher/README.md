# Craftlehem Launcher

A fast, good-looking Minecraft: Java Edition launcher for modpacks. Made by **coldskiess**.

- **Instances** for Vanilla, Fabric, Quilt, NeoForge and Forge, each with its own mods, worlds and settings
- **Discover** tab: search Modrinth for modpacks, mods, shaders and resource packs. Required dependencies install automatically
- **One-click modpacks**: install any Modrinth modpack, or import a `.mrpack` file
- **Java handled for you**: downloads Mojang's official Java runtime for each Minecraft version
- **Tuned for big packs**: an optimised G1 garbage-collector preset by default, and generational ZGC for Java 21+
- **Featured server card** with live player count and a Join button that connects straight to the server
- **Live console** for every instance, with warnings and errors highlighted
- Microsoft sign-in, with tokens encrypted by Windows

## Before you release: Microsoft sign-in

Every launcher needs its **own** Azure app ID, approved by Mojang. Without approval, Minecraft rejects logins with "Invalid app registration".

1. Go to <https://portal.azure.com>, then **Microsoft Entra ID → App registrations → New registration**.
   - Name: `Craftlehem Launcher` (players see this name on the Microsoft sign-in page)
   - Supported account types: **Personal Microsoft accounts only**
   - Redirect URI: leave empty
2. In the new app, open **Authentication**, set **Allow public client flows** to **Yes** and save.
3. Copy the **Application (client) ID** and the **Directory (tenant) ID** from **Overview**.
4. Submit both at <https://aka.ms/mce-reviewappid> (Minecraft "App ID review"). Approval usually takes days to a couple of weeks.
5. When approved, put the client ID in `src/core/build-config.json`:
   ```json
   { "msClientId": "your-client-id-here" }
   ```
   Client IDs are public and are not secrets. Never use another launcher's ID.

Until the ID is approved, you can paste it under **Settings → Microsoft sign-in** to test the login flow. It fails at the last step until Mojang approves it.

## Building

You need [Node.js](https://nodejs.org) 20 or newer.

```bash
npm install
npm start                 # run the launcher in development
npm run dist:win          # build the Windows installer + portable exe into dist/
```

Run `npm run dist:win` **on Windows** to get the full `Setup.exe` installer (NSIS). On Linux or macOS without Wine, use `npx electron-builder --win portable zip` to get the portable `.exe`.

## Where things are stored

`%APPDATA%\CraftlehemLauncher\`

| Folder | What's in it |
|---|---|
| `instances/<name>/minecraft` | Each instance's game folder (mods, saves, config, screenshots) |
| `versions`, `libraries`, `assets` | Shared Minecraft files, downloaded once for all instances |
| `runtimes` | Mojang's Java runtimes |
| `accounts.json` | Accounts. Refresh tokens are encrypted with Windows DPAPI |
| `settings.json` | Launcher settings |

## Project layout

```
src/core/        launcher engine (plain Node, no Electron) — can be tested on its own
  launch.js      builds the Java command line and starts the game
  versions.js    Mojang version metadata, libraries, natives, assets
  java.js        Mojang Java runtimes
  loaders/       Fabric, Quilt, Forge, NeoForge
  auth/          Microsoft → Xbox → Minecraft sign-in
  modrinth.js    search, mod install, .mrpack modpacks
  serverping.js  Minecraft server list ping
  manager.js     instances, settings, accounts, running games
src/main/        Electron main process + preload bridge
src/renderer/    the window (HTML/CSS/JS)
build/           icon + Windows exe branding hook
```

## Licence

GPL-3.0. Fonts: Chakra Petch and Inter (SIL Open Font License).
Not affiliated with Mojang or Microsoft. Minecraft is a trademark of Mojang AB.
